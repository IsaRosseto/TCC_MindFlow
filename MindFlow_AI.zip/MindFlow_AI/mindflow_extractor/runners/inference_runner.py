"""
mindflow_extractor/runners/inference_runner.py
==============================================
Inferência em tempo real via webcam usando o modelo LSTM treinado.

Carrega o modelo treinado + scaler + PCA de outputs/training/ e
exibe a predição de engajamento ao vivo na tela.

Uso:
    python -m mindflow_extractor.runners.inference_runner
    python -m mindflow_extractor.runners.inference_runner --camera 0
    python -m mindflow_extractor.runners.inference_runner --model outputs/training/lstm_mindflow.pt

Atalhos:
    Q / ESC  — encerrar
    L        — toggle landmarks faciais
    P        — toggle esqueleto corporal
    R        — resetar buffer temporal
    S        — salvar screenshot
"""
from __future__ import annotations

import sys
import time
from collections import deque
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

# Garante que o pacote seja encontrado
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mindflow_extractor.pipeline import MindFlowPipeline, FEATURE_NAMES

try:
    import mediapipe as mp
    _mp_drawing        = mp.solutions.drawing_utils
    _mp_drawing_styles = mp.solutions.drawing_styles
    _mp_face_mesh      = mp.solutions.face_mesh
    _mp_pose           = mp.solutions.pose
    _FACE_CONNECTIONS  = _mp_face_mesh.FACEMESH_TESSELATION
    _FACE_CONTOURS     = _mp_face_mesh.FACEMESH_CONTOURS
    _FACE_IRISES       = _mp_face_mesh.FACEMESH_IRISES
    _POSE_CONNECTIONS  = _mp_pose.POSE_CONNECTIONS
except ImportError:
    _mp_drawing = None
    _FACE_CONNECTIONS = _FACE_CONTOURS = _POSE_CONNECTIONS = None


# ---------------------------------------------------------------------------
# Constantes visuais
# ---------------------------------------------------------------------------

CLASS_NAMES = [
    "Very Low\nEngagement",
    "Low\nEngagement",
    "High\nEngagement",
    "Very High\nEngagement",
]

# Nomes das 4 dimensões DAiSEE para exibição
TASK_DISPLAY = [
    "Engajamento",   # 0
    "Tedios",        # 1
    "Confusao",      # 2
    "Frustracao",    # 3
]

# Cores BGR por dimensão
TASK_COLORS_BGR = [
    (80,  220,  80),    # Engajamento — verde
    (0,   180, 220),    # Tédio       — laranja
    (220,  80, 220),    # Confusão    — roxo
    (0,   100, 220),    # Frustração  — vermelho
]

_WHITE  = (230, 230, 230)
_GRAY   = (140, 140, 140)
_BLACK  = (10,  10,  10)


# ---------------------------------------------------------------------------
# Carregamento do modelo
# ---------------------------------------------------------------------------

def load_artifacts(
    model_path: Path,
    scaler_path: Path,
    pca_path: Path,
    cfg_module_path=None,
):
    """Carrega modelo multi-output, scaler e PCA."""
    import torch
    import joblib
    from training.config import MindFlowTrainingConfig
    from training.model import MindFlowLSTM

    cfg = MindFlowTrainingConfig()

    if not scaler_path.exists():
        raise FileNotFoundError(f"Scaler não encontrado: {scaler_path}")
    if not pca_path.exists():
        raise FileNotFoundError(f"PCA não encontrado: {pca_path}")
    if not model_path.exists():
        raise FileNotFoundError(f"Modelo não encontrado: {model_path}")

    scaler = joblib.load(scaler_path)
    pca    = joblib.load(pca_path)
    input_dim = pca.n_components_

    model = MindFlowLSTM(
        input_dim=input_dim,
        hidden_1=cfg.model.lstm_hidden_1,
        hidden_2=cfg.model.lstm_hidden_2,
        dropout=0.0,
    )
    state = torch.load(model_path, map_location="cpu", weights_only=True)
    model.load_state_dict(state)
    model.eval()

    print(f"  Modelo carregado: {model_path.name}")
    print(f"  Input dim (pós-PCA): {input_dim}")
    return model, scaler, pca, cfg


# ---------------------------------------------------------------------------
# Processamento do buffer
# ---------------------------------------------------------------------------

def predict_from_buffer(
    buffer:  deque,
    model,
    scaler,
    pca,
    seq_len: int = 30,
):
    """
    Dado um buffer de vetores 120d, roda normalização → PCA → LSTM multi-output.

    Retorna lista de 4 arrays de probabilidades (uma por dimensão DAiSEE),
    ou (None, None) se buffer insuficiente.
    """
    import torch

    if len(buffer) < seq_len:
        return None

    window = np.array(list(buffer)[-seq_len:], dtype=np.float32)
    window = np.nan_to_num(window, nan=0.0)

    window_flat = window.reshape(-1, window.shape[1])
    window_flat = scaler.transform(window_flat)
    window_flat = pca.transform(window_flat)
    window = window_flat.reshape(1, seq_len, -1)

    x = torch.from_numpy(window).float()
    with torch.no_grad():
        logits_list = model(x)   # lista de 4 tensors (1, 4)
        probs_list  = [torch.softmax(lg, dim=-1).squeeze().numpy()
                       for lg in logits_list]

    return probs_list   # lista de 4 arrays shape (4,)


# ---------------------------------------------------------------------------
# Funções de desenho
# ---------------------------------------------------------------------------

def _draw_face_landmarks(frame_bgr, mp_face_landmarks) -> None:
    if mp_face_landmarks is None or _mp_drawing is None:
        return
    _mp_drawing.draw_landmarks(
        frame_bgr, mp_face_landmarks, _FACE_CONNECTIONS,
        None,
        _mp_drawing.DrawingSpec(color=(0, 70, 35), thickness=1),
    )
    _mp_drawing.draw_landmarks(
        frame_bgr, mp_face_landmarks, _FACE_CONTOURS,
        _mp_drawing.DrawingSpec(color=(0, 220, 100), thickness=1, circle_radius=1),
        _mp_drawing.DrawingSpec(color=(0, 200, 255), thickness=1),
    )
    _mp_drawing.draw_landmarks(
        frame_bgr, mp_face_landmarks, _FACE_IRISES,
        None,
        _mp_drawing.DrawingSpec(color=(255, 220, 0), thickness=2),
    )


def _draw_pose_skeleton(frame_bgr, mp_pose_landmarks) -> None:
    if mp_pose_landmarks is None or _mp_drawing is None:
        return
    _mp_drawing.draw_landmarks(
        frame_bgr, mp_pose_landmarks, _POSE_CONNECTIONS,
        _mp_drawing.DrawingSpec(color=(255, 180, 0), thickness=4, circle_radius=4),
        _mp_drawing.DrawingSpec(color=(0, 180, 255), thickness=2),
    )


def _draw_prediction_panel(
    frame_bgr:  np.ndarray,
    probs_list: Optional[list],   # lista de 4 arrays (4,) ou None
    n_buffered: int,
    seq_len:    int,
    fps:        float,
) -> None:
    """Painel com as 4 dimensões DAiSEE e nível atual de cada uma."""
    h, w = frame_bgr.shape[:2]
    panel_w = 300
    x0 = w - panel_w

    # Fundo do painel
    overlay = frame_bgr.copy()
    cv2.rectangle(overlay, (x0, 0), (w, h), (10, 10, 18), -1)
    cv2.addWeighted(overlay, 0.82, frame_bgr, 0.18, 0, frame_bgr)
    cv2.line(frame_bgr, (x0, 0), (x0, h), (60, 80, 60), 2)

    # Título
    y = 30
    cv2.putText(frame_bgr, "MindFlow AI", (x0 + 8, y),
                cv2.FONT_HERSHEY_SIMPLEX, 0.65, (80, 220, 80), 2)
    y += 20
    cv2.putText(frame_bgr, f"FPS: {fps:.1f}  Buffer: {min(n_buffered,seq_len)}/{seq_len}",
                (x0 + 8, y), cv2.FONT_HERSHEY_SIMPLEX, 0.37, _GRAY, 1)
    y += 14
    cv2.line(frame_bgr, (x0 + 4, y), (w - 4, y), (60, 60, 90), 1)
    y += 14

    if probs_list is None:
        # Aguardando buffer
        pct = int((n_buffered / seq_len) * (panel_w - 24))
        cv2.putText(frame_bgr, "Aguardando frames...",
                    (x0 + 8, y), cv2.FONT_HERSHEY_SIMPLEX, 0.45, _GRAY, 1)
        y += 20
        cv2.rectangle(frame_bgr, (x0 + 8, y), (x0 + 8 + pct, y + 10), (80, 200, 80), -1)
        cv2.rectangle(frame_bgr, (x0 + 8, y), (w - 8, y + 10), _GRAY, 1)
        return

    # Níveis textuais por pontuação (média ponderada)
    LEVEL_LABELS = ["Muito Baixo", "Baixo", "Alto", "Muito Alto"]

    bar_full = panel_w - 20
    dominant_task = 0  # Engajamento define a borda

    for t, (task_name, col, probs) in enumerate(zip(TASK_DISPLAY, TASK_COLORS_BGR, probs_list)):
        # Nível predito (argmax)
        level_idx = int(probs.argmax())
        level_lbl = LEVEL_LABELS[level_idx]
        conf      = probs[level_idx]

        # Linha 1: Nome da dimensão + nível
        cv2.putText(frame_bgr, task_name, (x0 + 8, y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.46, col, 2)
        pct_txt = f"{level_lbl}  {conf*100:.0f}%"
        txt_w = cv2.getTextSize(pct_txt, cv2.FONT_HERSHEY_SIMPLEX, 0.36, 1)[0][0]
        cv2.putText(frame_bgr, pct_txt, (w - 8 - txt_w, y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.36, col, 1)
        y += 12

        # Barra de confiança (proporcional ao argmax)
        blen = int(conf * bar_full)
        cv2.rectangle(frame_bgr, (x0 + 8, y), (x0 + 8 + blen, y + 7), col, -1)
        cv2.rectangle(frame_bgr, (x0 + 8, y), (x0 + 8 + bar_full, y + 7), (50, 50, 65), 1)
        y += 16

        # Separador entre dimensões
        if t < 3:
            cv2.line(frame_bgr, (x0 + 4, y), (w - 4, y), (40, 40, 55), 1)
            y += 8

    # Borda do frame — cor do Engajamento (task 0)
    eng_level = int(probs_list[0].argmax())
    border_colors = [
        (0,   50, 220),   # muito baixo — vermelho
        (0,  180, 220),   # baixo       — laranja
        (80, 200,  60),   # alto        — verde
        (220, 120,  0),   # muito alto  — azul
    ]
    cv2.rectangle(frame_bgr, (0, 0), (x0 - 3, h - 1), border_colors[eng_level], 3)

    # Atalhos no rodapé
    y = h - 38
    cv2.line(frame_bgr, (x0 + 4, y - 8), (w - 4, y - 8), (60, 60, 90), 1)
    cv2.putText(frame_bgr, "Q=sair  S=foto  R=reset",
                (x0 + 6, y + 4), cv2.FONT_HERSHEY_SIMPLEX, 0.34, _GRAY, 1)
    cv2.putText(frame_bgr, "L=facemesh  P=pose",
                (x0 + 6, y + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.34, _GRAY, 1)


# ---------------------------------------------------------------------------
# Runner principal
# ---------------------------------------------------------------------------

def run_inference_webcam(
    camera_index: int = 0,
    model_path:   Optional[Path] = None,
    output_dir:   Optional[Path] = None,
) -> None:
    """
    Captura webcam e exibe predição de engajamento em tempo real.

    Args:
        camera_index : índice da câmera OpenCV (0 = padrão)
        model_path   : caminho para lstm_mindflow.pt
                       (default: outputs/training/lstm_mindflow.pt)
        output_dir   : pasta para screenshots
    """
    training_dir = ROOT / "outputs" / "training"
    if model_path is None:
        model_path = training_dir / "lstm_mindflow.pt"
    scaler_path = training_dir / "scaler.joblib"
    pca_path    = training_dir / "pca.joblib"

    if output_dir is None:
        output_dir = ROOT / "outputs" / "inference_screenshots"
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("  MindFlow AI — Inferência em Tempo Real via Webcam")
    print("=" * 60)
    print("  Carregando modelo...")

    model, scaler, pca, cfg = load_artifacts(model_path, scaler_path, pca_path)

    seq_len = cfg.features.sequence_len   # 30 frames
    buffer: deque = deque(maxlen=seq_len * 4)   # buffer grande, pega últimos 30

    print(f"  Abrindo câmera {camera_index}...")
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        raise RuntimeError(f"Não foi possível abrir a câmera {camera_index}.")

    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  960)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 540)
    cap.set(cv2.CAP_PROP_FPS, 30)

    window_name = "MindFlow AI — Inferencia"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, 1100, 600)

    print("  Pronto! Olhe para a câmera.")
    print("  [Q]/[ESC] encerrar | [S] screenshot | [R] reset buffer")
    print("  [L] toggle FaceMesh | [P] toggle Pose")
    print("-" * 60)

    frame_count         = 0
    t_prev              = time.perf_counter()
    show_face           = True
    show_pose           = True
    current_probs_list  = None   # lista de 4 arrays (4,)
    last_infer_frame    = -999
    INFER_EVERY         = 15

    with MindFlowPipeline() as pipe:
        while True:
            ret, frame_bgr = cap.read()
            if not ret:
                print("[AVISO] Frame não recebido.")
                break

            frame_bgr = cv2.flip(frame_bgr, 1)
            frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)

            t_now = time.perf_counter()
            fps   = 1.0 / max(t_now - t_prev, 1e-6)
            t_prev = t_now
            timestamp_ms = t_now * 1000.0

            result = pipe.process(frame_rgb, frame_idx=frame_count, timestamp_ms=timestamp_ms)

            # Acumula vetor no buffer
            buffer.append(result.vector.copy())

            # Atualiza predição a cada INFER_EVERY frames
            if frame_count - last_infer_frame >= INFER_EVERY:
                result_probs = predict_from_buffer(
                    buffer, model, scaler, pca, seq_len
                )
                if result_probs is not None:
                    current_probs_list = result_probs
                last_infer_frame = frame_count

            # Overlays de landmarks
            if show_face:
                _draw_face_landmarks(frame_bgr, result.mp_face_landmarks)
            if show_pose:
                _draw_pose_skeleton(frame_bgr, result.mp_pose_landmarks)

            # Painel de predição
            _draw_prediction_panel(
                frame_bgr,
                current_probs_list,
                len(buffer),
                seq_len,
                fps,
            )

            cv2.imshow(window_name, frame_bgr)

            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), ord("Q"), 27):
                break
            elif key in (ord("s"), ord("S")):
                path = output_dir / f"inference_{frame_count:06d}.png"
                cv2.imwrite(str(path), frame_bgr)
                print(f"  Screenshot salvo: {path}")
            elif key in (ord("r"), ord("R")):
                buffer.clear()
                pipe.reset_temporal_buffer()
                current_probs_list = None
                print("  Buffer resetado.")
            elif key in (ord("l"), ord("L")):
                show_face = not show_face
            elif key in (ord("p"), ord("P")):
                show_pose = not show_pose

            frame_count += 1

    cap.release()
    cv2.destroyAllWindows()
    print(f"\n  Encerrado após {frame_count} frames.")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="MindFlow AI — Inferência via Webcam")
    parser.add_argument("--camera", type=int, default=0,
                        help="Índice da câmera (default: 0)")
    parser.add_argument("--model", type=Path, default=None,
                        help="Caminho para lstm_mindflow.pt")
    args = parser.parse_args()

    run_inference_webcam(
        camera_index=args.camera,
        model_path=args.model,
    )
