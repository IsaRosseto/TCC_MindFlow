"""
training/model.py
=================
LSTM multi-output do MindFlow AI — prediz 4 dimensões simultaneamente.

Arquitetura:
    Input(30, D) → LSTM(128) → Dropout → LSTM(64) → 4 cabeças independentes

Cada cabeça:
    Dense(64 → 4)  → Softmax   (4 níveis: 0=muito baixo … 3=muito alto)

Dimensões de saída:
    head 0: Engajamento   (engagement)
    head 1: Tédio         (boredom)
    head 2: Confusão      (confusion)
    head 3: Frustração    (frustration)
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional, Tuple

import torch
import torch.nn as nn

from training.config import MindFlowTrainingConfig, DEFAULT_CFG
from training.dataset import TASK_NAMES

logger = logging.getLogger(__name__)

N_TASKS   = 4   # engagement, boredom, confusion, frustration
N_LEVELS  = 4   # 0 … 3


class MindFlowLSTM(nn.Module):
    """
    LSTM multi-output para classificação de estados cognitivos.

    Parâmetros
    ----------
    input_dim : dimensão do vetor por frame (n_components do PCA)
    hidden_1  : unidades da 1ª camada LSTM (padrão 128)
    hidden_2  : unidades da 2ª camada LSTM (padrão 64)
    n_tasks   : número de dimensões a prever (padrão 4)
    n_levels  : número de classes por dimensão (padrão 4)
    dropout   : taxa de dropout entre camadas (padrão 0.3)
    """

    def __init__(
        self,
        input_dim:  int   = 120,
        hidden_1:   int   = 128,
        hidden_2:   int   = 64,
        n_tasks:    int   = N_TASKS,
        n_levels:   int   = N_LEVELS,
        dropout:    float = 0.3,
        # Aliases de compatibilidade com código antigo
        num_classes: Optional[int] = None,
    ):
        super().__init__()
        self.input_dim = input_dim
        self.hidden_1  = hidden_1
        self.hidden_2  = hidden_2
        self.n_tasks   = n_tasks
        self.n_levels  = n_levels

        self.lstm1 = nn.LSTM(input_dim,  hidden_1, batch_first=True)
        self.drop  = nn.Dropout(p=dropout)
        self.lstm2 = nn.LSTM(hidden_1,   hidden_2, batch_first=True)

        # 4 cabeças independentes — uma por dimensão DAiSEE
        self.heads = nn.ModuleList([
            nn.Linear(hidden_2, n_levels) for _ in range(n_tasks)
        ])

        self._init_weights()

    def _init_weights(self) -> None:
        for name, param in self.named_parameters():
            if "weight_ih" in name:
                nn.init.xavier_uniform_(param.data)
            elif "weight_hh" in name:
                nn.init.orthogonal_(param.data)
            elif "bias" in name:
                param.data.fill_(0)
                n = param.size(0)
                param.data[n // 4: n // 2].fill_(1)  # forget gate bias = 1

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        """
        x       : (batch, seq_len, input_dim)
        retorna : lista de n_tasks tensors, cada (batch, n_levels) — logits sem softmax
        """
        out1, _ = self.lstm1(x)
        out1    = self.drop(out1)
        out2, _ = self.lstm2(out1)
        h       = out2[:, -1, :]             # último hidden state: (batch, hidden_2)
        return [head(h) for head in self.heads]

    def predict_proba(self, x: torch.Tensor) -> List[torch.Tensor]:
        """Lista de probabilidades softmax por dimensão — para inferência."""
        with torch.no_grad():
            logits_list = self.forward(x)
            return [torch.softmax(lg, dim=-1) for lg in logits_list]

    def predict(self, x: torch.Tensor) -> torch.Tensor:
        """Tensor (batch, n_tasks) com a classe predita por dimensão."""
        probs = self.predict_proba(x)
        return torch.stack([p.argmax(dim=-1) for p in probs], dim=1)

    def summary(self) -> str:
        total     = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        heads_str = "  ".join(f"head_{i}({TASK_NAMES[i]})" for i in range(self.n_tasks))
        return "\n".join([
            "MindFlowLSTM (multi-output)",
            f"  Input       : (batch, seq, {self.input_dim})",
            f"  LSTM 1      : {self.input_dim} → {self.hidden_1}",
            f"  Dropout",
            f"  LSTM 2      : {self.hidden_1} → {self.hidden_2}",
            f"  Heads       : {heads_str}",
            f"  Cada cabeça : Linear({self.hidden_2} → {self.n_levels})",
            f"  Parâmetros  : {total:,} total | {trainable:,} treináveis",
        ])


def build_model(
    cfg: MindFlowTrainingConfig = DEFAULT_CFG,
    input_dim: Optional[int] = None,
) -> MindFlowLSTM:
    dim = input_dim if input_dim is not None else cfg.features.vector_dim
    model = MindFlowLSTM(
        input_dim=dim,
        hidden_1=cfg.model.lstm_hidden_1,
        hidden_2=cfg.model.lstm_hidden_2,
        n_tasks=N_TASKS,
        n_levels=N_LEVELS,
        dropout=cfg.model.dropout,
    )
    logger.info("Modelo construído:\n%s", model.summary())
    return model


def load_model(
    path: Path,
    cfg: MindFlowTrainingConfig = DEFAULT_CFG,
    input_dim: Optional[int] = None,
    device: str = "cpu",
) -> MindFlowLSTM:
    model = build_model(cfg, input_dim=input_dim)
    state = torch.load(path, map_location=device, weights_only=True)
    model.load_state_dict(state)
    model.eval()
    return model
