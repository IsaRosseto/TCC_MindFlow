# training — pipeline de treinamento MindFlow AI
