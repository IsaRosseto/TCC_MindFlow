import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

DARK = "#0D1117"
CARD = "#161B22"
BORDER = "#30363D"
TEXT = "#E6EDF3"
MUTED = "#8B949E"

fig, ax = plt.subplots(figsize=(6, 4))
fig.patch.set_facecolor(DARK)
ax.set_facecolor(DARK)
ax.set_xlim(-1.2, 1.2)
ax.set_ylim(-0.3, 1.2)
ax.axis("off")

value = 0.84
color = "#00E676"
title = "Acurácia (Velocímetro)"

# --- Velocímetro Redesign ---
r_out = 1.0
r_in = 0.8

# Zonas de cor sólidas (faixas do velocímetro)
zones = [
    (0.0, 0.4, "#F44336"),  # Vermelho
    (0.4, 0.65, "#FF9800"), # Laranja
    (0.65, 0.80, "#3FB950"),# Verde claro
    (0.80, 1.0, "#00E676")  # Verde forte
]

for z_start, z_end, z_col in zones:
    t = np.linspace(np.pi - z_start * np.pi, np.pi - z_end * np.pi, 100)
    ax.fill_between(
        r_out * np.cos(t), r_out * np.sin(t),
        r_in * np.cos(t), r_in * np.sin(t),
        color=z_col, alpha=0.9, zorder=1,
    )
    
    # Tick mark for separation
    ax.plot([r_in * np.cos(np.pi - z_end * np.pi), r_out * np.cos(np.pi - z_end * np.pi)],
            [r_in * np.sin(np.pi - z_end * np.pi), r_out * np.sin(np.pi - z_end * np.pi)],
            color=DARK, lw=2, zorder=2)

# Needle (polygon)
needle_angle = np.pi - value * np.pi
needle_len = 0.95
needle_base = 0.05

# Coordinates for the polygon: tip, base left, base right
tip_x = needle_len * np.cos(needle_angle)
tip_y = needle_len * np.sin(needle_angle)

left_angle = needle_angle + np.pi/2
right_angle = needle_angle - np.pi/2

left_x = needle_base * np.cos(left_angle)
left_y = needle_base * np.sin(left_angle)

right_x = needle_base * np.cos(right_angle)
right_y = needle_base * np.sin(right_angle)

polygon = patches.Polygon([[tip_x, tip_y], [left_x, left_y], [right_x, right_y]], 
                          closed=True, facecolor=TEXT, edgecolor=TEXT, zorder=10)
ax.add_patch(polygon)

# Center pivot
ax.plot(0, 0, "o", color=TEXT, ms=16, zorder=11)
ax.plot(0, 0, "o", color=DARK, ms=6, zorder=12)

# Ticks and labels
for pct in [0, 25, 50, 75, 100]:
    ang = np.pi - (pct / 100) * np.pi
    tx = 1.15 * np.cos(ang)
    ty = 1.15 * np.sin(ang)
    ax.text(tx, ty, f"{pct}", ha="center", va="center", fontsize=9, color=MUTED, weight="bold")

# Value Text
ax.text(0, -0.15, f"{value*100:.1f}%", ha="center", va="center", fontsize=24, color=TEXT, weight="bold")

fig.savefig("test_gauge_speedometer.png", dpi=150, bbox_inches="tight", facecolor=DARK)
