"""
training/preprocessing.py
==========================
Pré-processamento do pipeline de treinamento do MindFlow AI.

Etapas (na ordem correta conforme metodologia):
  1. Normalização Z-score      ← fit apenas no treino
  2. BorderlineSMOTE           ← apenas no treino, pós-normalização
  3. PCA                       ← obrigatório, fit apenas no treino

Ordem é crítica:
  - Splits já vêm separados (divisão oficial DAiSEE Train/Val/Test)
  - Normalização fit SOMENTE no treino para evitar data leakage
  - SMOTE apenas no treino: val e test permanecem com distribuição real
  - PCA APÓS SMOTE: componentes calculados sobre espaço já balanceado

Por que BorderlineSMOTE?
  O DAiSEE tem viés severo: ~70-80% das amostras são "high engagement"
  (labels 2-3). O SMOTE básico gera sintéticos em regiões fáceis do
  centro da nuvem. O BorderlineSMOTE (Han et al., 2005) foca apenas
  nos exemplos FRONTEIRIÇOS — aqueles com vizinhos de classes diferentes
  — melhorando especificamente o F1 nas classes minoritárias sem inflar
  regiões que o modelo já classifica bem.
  kind="borderline-1": usa apenas amostras "borderline" reais como semente.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Optional, Tuple

import joblib
import numpy as np
from imblearn.over_sampling import BorderlineSMOTE
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler

from training.config import MindFlowTrainingConfig, DEFAULT_CFG

logger = logging.getLogger(__name__)

SplitData = Tuple[
    np.ndarray, np.ndarray,   # X_train, y_train
    np.ndarray, np.ndarray,   # X_val,   y_val
    np.ndarray, np.ndarray,   # X_test,  y_test
]


# ---------------------------------------------------------------------------
# 1. Normalização Z-score
# ---------------------------------------------------------------------------

def fit_scaler(
    X_train: np.ndarray,
    scaler_type: str = "standard",
    save_path: Optional[Path] = None,
) -> object:
    """
    Ajusta o scaler APENAS nos dados de treino.

    X_train : (N_train, seq_len, 120)
    """
    scaler_map = {
        "standard": StandardScaler,
        "minmax":   MinMaxScaler,
        "robust":   RobustScaler,
    }
    if scaler_type not in scaler_map:
        raise ValueError(f"scaler_type inválido: {scaler_type}. Opções: {list(scaler_map)}")

    scaler = scaler_map[scaler_type]()

    # Reshape para 2D: (N*seq_len, 120) → fit → reshape de volta
    n, seq, feat = X_train.shape
    X_flat = X_train.reshape(-1, feat)
    scaler.fit(X_flat)
    logger.info("Scaler '%s' ajustado em %d amostras × %d features", scaler_type, *X_flat.shape)

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(scaler, save_path)
        logger.info("Scaler salvo em: %s", save_path)

    return scaler


def apply_scaler(X: np.ndarray, scaler) -> np.ndarray:
    """Aplica o scaler a qualquer partição (train/val/test)."""
    n, seq, feat = X.shape
    X_flat = X.reshape(-1, feat)
    X_scaled = scaler.transform(X_flat)
    return X_scaled.reshape(n, seq, feat)


# ---------------------------------------------------------------------------
# 2. BorderlineSMOTE
# ---------------------------------------------------------------------------

def apply_smote(
    X_train: np.ndarray,
    y_train: np.ndarray,
    k_neighbors: int = 5,
    seed: int = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Balanceia o conjunto de treino com BorderlineSMOTE.

    y_train pode ser:
      - (N,)   — single-label (engagement)
      - (N, 4) — multi-label [engagement, boredom, confusion, frustration]

    O SMOTE usa apenas engagement (dim 0) como critério de balanceamento.
    Os rótulos das outras dimensões são propagados usando os mesmos índices.

    X_train : (N, seq_len, 120) — já normalizado
    y_train : (N,) ou (N, 4)
    """
    multi_label = (y_train.ndim == 2)
    y_engagement = y_train[:, 0] if multi_label else y_train

    n, seq, feat = X_train.shape
    X_flat = X_train.reshape(n, seq * feat)

    counts = np.bincount(y_engagement)
    min_class_count = counts[counts > 0].min()
    k = min(k_neighbors, min_class_count - 1)
    if k < k_neighbors:
        logger.warning(
            "⚠️  k_neighbors reduzido de %d para %d (menor classe tem %d amostras)",
            k_neighbors, k, min_class_count,
        )
    if k < 1:
        logger.warning("⚠️  Classe muito pequena para SMOTE — pulando balanceamento.")
        return X_train, y_train

    smote = BorderlineSMOTE(
        k_neighbors=k,
        kind="borderline-1",
        random_state=seed,
    )
    X_resampled, y_eng_resampled = smote.fit_resample(X_flat, y_engagement)

    n_new = len(X_resampled)
    X_resampled = X_resampled.reshape(n_new, seq, feat)

    if multi_label:
        # Para amostras sintéticas, copia o label do sample original mais próximo
        # (SMOTE garante que amostras sintéticas herdam a classe da semente)
        # Reconstrói y completo usando os rótulos de engagement reamostrado
        n_orig = n
        y_resampled_full = np.zeros((n_new, y_train.shape[1]), dtype=np.int64)
        y_resampled_full[:n_orig] = y_train   # originais — preserva todos os labels
        for i in range(n_orig, n_new):
            # Sintético: usa o engagement que o SMOTE gerou; outras dims = 0 (conservador)
            y_resampled_full[i, 0] = y_eng_resampled[i]
        y_out = y_resampled_full
    else:
        y_out = y_eng_resampled

    unique, cnts = np.unique(y_eng_resampled, return_counts=True)
    logger.info(
        "BorderlineSMOTE: %d → %d amostras | nova dist engajamento: %s",
        n, n_new,
        dict(zip(unique.tolist(), cnts.tolist())),
    )
    return X_resampled, y_out


def apply_smote_multioutput(
    X_train: np.ndarray,
    y_train: np.ndarray,
    k_neighbors: int = 5,
    seed: int = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Aplica BorderlineSMOTE por dimensão no modo multi-output.

    Para cada uma das 4 dimensões (engagement, boredom, confusion, frustration),
    roda o SMOTE independentemente usando aquela dimensão como alvo.
    As labels das outras dimensões para amostras sintéticas são propagadas
    do sample original (seed) que o SMOTE selecionou para gerar o sintético.

    Resultado: concatenação dos originais + sintéticos de todas as dimensões.
    """
    from sklearn.neighbors import NearestNeighbors

    n, seq, feat = X_train.shape
    X_flat = X_train.reshape(n, seq * feat)
    n_dims = y_train.shape[1]

    X_extra = []
    y_extra = []

    for dim_idx in range(n_dims):
        y_dim = y_train[:, dim_idx]
        counts = np.bincount(y_dim)
        min_count = counts[counts > 0].min()
        k = min(k_neighbors, min_count - 1)

        if k < 1:
            logger.warning(
                "⚠️  Dimensão %d: classe muito pequena para SMOTE — pulando.", dim_idx
            )
            continue

        smote = BorderlineSMOTE(
            k_neighbors=k,
            kind="borderline-1",
            random_state=seed + dim_idx,  # seed diferente por dimensão
        )
        X_res, y_res_dim = smote.fit_resample(X_flat, y_dim)

        n_new = len(X_res)
        n_synthetic = n_new - n

        if n_synthetic == 0:
            continue

        # Para os sintéticos, propaga labels das outras dimensões do vizinho mais próximo
        X_synthetic_flat = X_res[n:]  # apenas os novos sintéticos

        nbrs = NearestNeighbors(n_neighbors=1).fit(X_flat)
        _, seed_indices = nbrs.kneighbors(X_synthetic_flat)
        seed_indices = seed_indices.flatten()

        y_synthetic = np.zeros((n_synthetic, n_dims), dtype=np.int64)
        for i, seed_idx in enumerate(seed_indices):
            y_synthetic[i] = y_train[seed_idx]  # copia todas as labels do vizinho
        y_synthetic[:, dim_idx] = y_res_dim[n:]  # sobrescreve a dim alvo com o valor do SMOTE

        X_extra.append(X_synthetic_flat.reshape(n_synthetic, seq, feat))
        y_extra.append(y_synthetic)

        unique, cnts = np.unique(y_res_dim, return_counts=True)
        logger.info(
            "  Dim %d: %d sintéticos | dist: %s",
            dim_idx, n_synthetic,
            dict(zip(unique.tolist(), cnts.tolist())),
        )

    if X_extra:
        X_out = np.concatenate([X_train] + X_extra, axis=0)
        y_out = np.concatenate([y_train] + y_extra, axis=0)
        logger.info(
            "BorderlineSMOTE multi-output: %d → %d amostras totais", n, len(X_out)
        )
    else:
        logger.warning("⚠️  SMOTE multi-output não gerou nenhum sintético.")
        X_out, y_out = X_train, y_train

    return X_out, y_out



# ---------------------------------------------------------------------------
# 3. PCA (obrigatório)
# ---------------------------------------------------------------------------

def fit_pca(
    X_train: np.ndarray,
    variance_threshold: float = 0.95,
    save_path: Optional[Path] = None,
) -> PCA:
    """
    Ajusta PCA no treino. Reduz a dimensão de features retendo
    `variance_threshold` da variância explicada.

    PCA é aplicado por frame (2D), não por sequência.
    """
    n, seq, feat = X_train.shape
    X_flat = X_train.reshape(-1, feat)

    pca = PCA(n_components=variance_threshold, svd_solver="full", random_state=42)
    pca.fit(X_flat)

    logger.info(
        "PCA ajustado: %d → %d componentes (%.1f%% variância retida)",
        feat, pca.n_components_, 100 * variance_threshold,
    )

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(pca, save_path)
        logger.info("PCA salvo em: %s", save_path)

    return pca


def apply_pca(X: np.ndarray, pca: PCA) -> np.ndarray:
    """Aplica PCA a qualquer partição."""
    n, seq, feat = X.shape
    X_flat = X.reshape(-1, feat)
    X_reduced = pca.transform(X_flat)
    n_components = X_reduced.shape[1]
    return X_reduced.reshape(n, seq, n_components)


# ---------------------------------------------------------------------------
# Função orquestradora (recebe splits já separados)
# ---------------------------------------------------------------------------

def preprocess_pipeline(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val:   np.ndarray,
    y_val:   np.ndarray,
    X_test:  np.ndarray,
    y_test:  np.ndarray,
    cfg: MindFlowTrainingConfig = DEFAULT_CFG,
    save_artifacts: bool = True,
) -> Tuple[SplitData, Dict]:
    """
    Executa o pipeline completo de pré-processamento na ordem correta.

    Recebe os 3 splits já separados (divisão oficial do DAiSEE).

    Retorna
    -------
    (X_train, y_train, X_val, y_val, X_test, y_test), artifacts_dict
    """
    p = cfg.preprocess

    multi_output = (y_train.ndim == 2 and y_train.shape[1] > 1)

    logger.info("=" * 55)
    logger.info("PIPELINE DE PRÉ-PROCESSAMENTO")
    logger.info("=" * 55)
    logger.info("  Train : %s  Val: %s  Test: %s",
                X_train.shape, X_val.shape, X_test.shape)
    if multi_output:
        logger.info("  Modo: multi-output (%d dimensões)", y_train.shape[1])

    # 1. Normalização (fit SOMENTE no treino)
    logger.info("[1/3] Normalização Z-score (fit no treino)")
    scaler = fit_scaler(
        X_train,
        scaler_type=p.scaler,
        save_path=cfg.scaler_path if save_artifacts else None,
    )
    X_train = apply_scaler(X_train, scaler)
    X_val   = apply_scaler(X_val,   scaler)
    X_test  = apply_scaler(X_test,  scaler)

    # 2. BorderlineSMOTE — por dimensão no modo multi-output
    #    Aplica SMOTE independentemente em cada uma das 4 dimensões.
    #    Para amostras sintéticas, os labels das outras dimensões são
    #    propagados do sample original (seed do SMOTE via índice).
    logger.info("[2/3] BorderlineSMOTE (somente no treino)")
    if multi_output:
        X_train, y_train = apply_smote_multioutput(
            X_train, y_train,
            k_neighbors=p.smote_k_neighbors,
            seed=p.smote_random_state,
        )
    else:
        X_train, y_train = apply_smote(
            X_train, y_train,
            k_neighbors=p.smote_k_neighbors,
            seed=p.smote_random_state,
        )


    # 3. PCA (obrigatório)
    logger.info("[3/3] PCA (fit no treino pós-SMOTE, aplicado em todos os splits)")
    pca = fit_pca(
        X_train,
        variance_threshold=p.pca_variance_threshold,
        save_path=cfg.pca_path if save_artifacts else None,
    )
    X_train = apply_pca(X_train, pca)
    X_val   = apply_pca(X_val,   pca)
    X_test  = apply_pca(X_test,  pca)

    logger.info("=" * 55)
    logger.info("Pré-processamento concluído.")
    logger.info(
        "  X_train: %s  X_val: %s  X_test: %s",
        X_train.shape, X_val.shape, X_test.shape,
    )
    logger.info("  Dimensão após PCA: %d componentes", X_train.shape[2])
    logger.info("=" * 55)

    artifacts = {"scaler": scaler, "pca": pca}
    return (X_train, y_train, X_val, y_val, X_test, y_test), artifacts
