"""
training/run_training.py
========================
Script de entrada único para o pipeline completo de treinamento.

Uso:
    # Treino com dados reais (DAiSEE extraído)
    python training/run_training.py

    # Treino com dados sintéticos (desenvolvimento)
    python training/run_training.py --synthetic

    # Treino + comparação com/sem PCA
    python training/run_training.py --compare-pca

    # Apenas avaliação (requer modelo já treinado)
    python training/run_training.py --eval-only

Saídas geradas em outputs/training/:
    lstm_mindflow.pt          — modelo treinado (pesos)
    scaler.joblib             — StandardScaler serializado
    pca.joblib                — PCA serializado (se use_pca=True)
    metrics.json              — métricas do conjunto de teste
    training_history.json     — curvas de treino/val por época
    classification_report.txt — relatório por classe (para o TCC)
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from dataclasses import replace
from pathlib import Path

# Garante que o pacote training seja encontrado ao rodar direto
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from training.config import MindFlowTrainingConfig, DEFAULT_CFG, OUTPUT_DIR
from training.train import train_model
from training.evaluate import evaluate_model

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)


def run(args: argparse.Namespace) -> None:

    # ----------------------------------------------------------------
    # Modo: apenas avaliação
    # ----------------------------------------------------------------
    if args.eval_only:
        logger.info("Modo: avaliação do modelo salvo em disco.")
        metrics = evaluate_model(save=True)
        logger.info("Concluído. Métricas em: %s", OUTPUT_DIR / "metrics.json")
        return

    # ----------------------------------------------------------------
    # Modo: comparação com/sem PCA
    # ----------------------------------------------------------------
    if args.compare_pca:
        logger.info("Modo: comparação com PCA vs. sem PCA.")
        results = {}

        for use_pca in [False, True]:
            label = "com_pca" if use_pca else "sem_pca"
            logger.info("=== Treinando %s ===", label)

            cfg = MindFlowTrainingConfig()
            cfg = replace(cfg, preprocess=replace(cfg.preprocess, use_pca=use_pca))

            history = train_model(
                cfg=cfg,
                use_synthetic=args.synthetic,
                save_model=(label == "sem_pca"),  # salva só o sem PCA como padrão
            )
            model   = history["_model"]
            X_test, y_test = history["_test_data"]
            metrics = evaluate_model(
                model=model, X_test=X_test, y_test=y_test,
                cfg=cfg, save=(label == "sem_pca"),
            )
            results[label] = {
                "f1_macro":  metrics["f1_macro"],
                "accuracy":  metrics["accuracy"],
                "use_pca":   use_pca,
                "epochs":    history["_best_epoch"],
            }

        print("\n" + "=" * 50)
        print("  COMPARAÇÃO PCA vs. SEM PCA")
        print("=" * 50)
        for label, r in results.items():
            print(f"  {label:12s}: F1={r['f1_macro']:.4f}  Acc={r['accuracy']:.4f}  "
                  f"melhor_época={r['epochs']}")
        print("=" * 50)

        cmp_path = OUTPUT_DIR / "pca_comparison.json"
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        with open(cmp_path, "w") as f:
            json.dump(results, f, indent=2)
        logger.info("Comparação salva em: %s", cmp_path)
        return

    # ----------------------------------------------------------------
    # Modo padrão: treino completo
    # ----------------------------------------------------------------
    logger.info("Modo: treinamento completo.")
    cfg = DEFAULT_CFG

    history = train_model(
        cfg=cfg,
        use_synthetic=args.synthetic,
        save_model=True,
    )

    model           = history["_model"]
    X_test, y_test  = history["_test_data"]

    metrics = evaluate_model(
        model=model,
        X_test=X_test,
        y_test=y_test,
        cfg=cfg,
        save=True,
    )

    logger.info("Pipeline concluído.")
    logger.info("  Modelo salvo  : %s", OUTPUT_DIR / "lstm_mindflow.pt")
    logger.info("  Métricas      : F1-macro=%.4f  Acc=%.4f",
                metrics["f1_macro"], metrics["accuracy"])


def main() -> None:
    parser = argparse.ArgumentParser(
        description="MindFlow AI — Pipeline de Treinamento",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--synthetic", action="store_true",
        help="Usar dados sintéticos (desenvolvimento sem DAiSEE)",
    )
    parser.add_argument(
        "--eval-only", action="store_true",
        help="Apenas avaliar modelo já treinado (não retreina)",
    )
    parser.add_argument(
        "--compare-pca", action="store_true",
        help="Treina duas vezes: com e sem PCA; compara métricas",
    )
    args = parser.parse_args()
    run(args)


if __name__ == "__main__":
    main()
