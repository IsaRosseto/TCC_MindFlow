import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import matplotlib.patches as patches

DARK = "#0D1117"
CARD = "#161B22"
BORDER = "#30363D"
TEXT = "#E6EDF3"
MUTED = "#8B949E"

fig, ax = plt.subplots(figsize=(6, 4))
fig.patch.set_facecolor(DARK)
ax.set_facecolor(DARK)
ax.set_xlim(-1.2, 1.2)
ax.set_ylim(-0.8, 1.2)
ax.axis("off")

value = 0.84
color = "#00E676"  # Color of the dimension
title = "Acurácia (Estilo Imagem)"

# The arc spans from start_angle to end_angle
# In the image, it's roughly from 210 degrees down to -30 degrees
start_angle = np.pi * (1.2) # 216 deg
end_angle = np.pi * (-0.2) # -36 deg
span = start_angle - end_angle

# Background arc
theta_bg = np.linspace(start_angle, end_angle, 200)
x_bg = np.cos(theta_bg)
y_bg = np.sin(theta_bg)
ax.plot(x_bg, y_bg, color=BORDER, linewidth=30, solid_capstyle="butt", zorder=1)

# Foreground arc
val_angle = start_angle - (value * span)
theta_val = np.linspace(start_angle, val_angle, 200)
x_val = np.cos(theta_val)
y_val = np.sin(theta_val)
ax.plot(x_val, y_val, color=color, linewidth=30, solid_capstyle="butt", zorder=2)

# Glow effect for the needle (fading line)
# We can draw multiple lines with decreasing alpha
num_segments = 50
needle_len = 0.85
r_vals = np.linspace(0, needle_len, num_segments)
for i in range(num_segments - 1):
    alpha = (i / num_segments)**2 # fade more towards center
    ax.plot([r_vals[i]*np.cos(val_angle), r_vals[i+1]*np.cos(val_angle)],
            [r_vals[i]*np.sin(val_angle), r_vals[i+1]*np.sin(val_angle)],
            color="#ffffff", linewidth=6, alpha=alpha, zorder=10)

# Bright tip
ax.plot([r_vals[-2]*np.cos(val_angle), r_vals[-1]*np.cos(val_angle)],
        [r_vals[-2]*np.sin(val_angle), r_vals[-1]*np.sin(val_angle)],
        color="#ffffff", linewidth=6, solid_capstyle="round", zorder=11)

# Ticks (0, 25, 50, 75, 100) placed inside the arc
for pct in [0, 25, 50, 75, 100]:
    ang = start_angle - (pct / 100) * span
    tx = 0.70 * np.cos(ang) # Inside the arc
    ty = 0.70 * np.sin(ang)
    ax.text(tx, ty, f"{pct}", ha="center", va="center", fontsize=10, color=TEXT, weight="bold")

# Value Text
ax.text(0, -0.4, f"{value*100:.1f}%", ha="center", va="center", fontsize=32, color=TEXT, weight="bold")

fig.savefig("test_gauge_image.png", dpi=150, bbox_inches="tight", facecolor=DARK)
