"""
training/model.py
=================
Arquitetura LSTM do MindFlow AI.

Conforme MindFlow_Metodologia.pdf §4.1 decisão 8:
    Input(30, D) → LSTM(128) → Dropout(0.3) → LSTM(64) → Dense(3) → Softmax

onde D = 120 (ou n_components do PCA se ativado).

Design choices registrados para a banca:
  - Duas camadas LSTM empilhadas: captura padrões de curto (camada 1)
    e médio prazo (camada 2) dentro da janela de 30 frames
  - Dropout entre camadas: regularização para evitar overfitting no
    dataset relativamente pequeno (DAiSEE tem ~9k clipes)
  - return_sequences=True apenas na camada 1 (passa sequência inteira
    para a camada 2); camada 2 retorna apenas o último estado oculto
  - Softmax implícito no CrossEntropyLoss do PyTorch (logits como saída)

Limitações (registrar no TCC):
  - Arquitetura unidirecional: processa apenas passado→presente.
    Bidirecional poderia melhorar, mas inviabiliza inferência em tempo
    real (exige sequência completa antes de classificar)
  - Janela fixa de 30 frames: estados que se desenvolvem em escalas
    maiores (minutos) não são capturados. Solução futura: hierarquia
    de modelos (LSTM local + agregador global)
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, Tuple

import torch
import torch.nn as nn

from training.config import MindFlowTrainingConfig, DEFAULT_CFG

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Arquitetura
# ---------------------------------------------------------------------------

class MindFlowLSTM(nn.Module):
    """
    Classificador LSTM para estados cognitivos.

    Parâmetros
    ----------
    input_dim : dimensão do vetor por frame (120 sem PCA, n_components com PCA)
    hidden_1  : unidades da primeira camada LSTM (padrão: 128)
    hidden_2  : unidades da segunda camada LSTM (padrão: 64)
    num_classes : número de classes de saída (padrão: 3)
    dropout   : taxa de dropout entre as camadas (padrão: 0.3)
    """

    def __init__(
        self,
        input_dim:   int   = 120,
        hidden_1:    int   = 128,
        hidden_2:    int   = 64,
        num_classes: int   = 3,
        dropout:     float = 0.3,
    ):
        super().__init__()

        self.input_dim   = input_dim
        self.hidden_1    = hidden_1
        self.hidden_2    = hidden_2
        self.num_classes = num_classes

        # Camada 1: processa sequência completa
        self.lstm1 = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_1,
            num_layers=1,
            batch_first=True,      # (batch, seq, features)
            dropout=0.0,           # dropout entre camadas, não dentro delas
        )

        self.dropout = nn.Dropout(p=dropout)

        # Camada 2: recebe sequência da camada 1, retorna último estado
        self.lstm2 = nn.LSTM(
            input_size=hidden_1,
            hidden_size=hidden_2,
            num_layers=1,
            batch_first=True,
        )

        # Classificador
        self.classifier = nn.Linear(hidden_2, num_classes)

        # Inicialização de pesos (ortogonal para LSTM, xavier para linear)
        self._init_weights()

    def _init_weights(self) -> None:
        """Inicialização que estabiliza o treinamento de LSTMs."""
        for name, param in self.named_parameters():
            if "weight_ih" in name:
                nn.init.xavier_uniform_(param.data)
            elif "weight_hh" in name:
                nn.init.orthogonal_(param.data)
            elif "bias" in name:
                param.data.fill_(0)
                # Bias da forget gate = 1 (trick clássico para gradientes)
                n = param.size(0)
                param.data[n // 4: n // 2].fill_(1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Parâmetros
        ----------
        x : (batch, seq_len, input_dim)

        Retorna
        -------
        logits : (batch, num_classes) — sem softmax (CrossEntropyLoss espera logits)
        """
        # LSTM 1: (batch, seq, input_dim) → (batch, seq, hidden_1)
        out1, _ = self.lstm1(x)
        out1 = self.dropout(out1)

        # LSTM 2: (batch, seq, hidden_1) → (batch, seq, hidden_2)
        out2, _ = self.lstm2(out1)

        # Pega apenas o último timestep: (batch, hidden_2)
        last_hidden = out2[:, -1, :]

        # Classificador: (batch, hidden_2) → (batch, num_classes)
        logits = self.classifier(last_hidden)
        return logits

    def predict_proba(self, x: torch.Tensor) -> torch.Tensor:
        """Retorna probabilidades (com softmax) — para inferência."""
        with torch.no_grad():
            logits = self.forward(x)
            return torch.softmax(logits, dim=-1)

    def predict(self, x: torch.Tensor) -> torch.Tensor:
        """Retorna classe predita (argmax) — para inferência."""
        return self.predict_proba(x).argmax(dim=-1)

    def summary(self) -> str:
        """Resumo da arquitetura para logging."""
        total_params = sum(p.numel() for p in self.parameters())
        trainable    = sum(p.numel() for p in self.parameters() if p.requires_grad)
        lines = [
            "MindFlowLSTM",
            f"  Input       : (batch, 30, {self.input_dim})",
            f"  LSTM 1      : {self.input_dim} → {self.hidden_1} unidades",
            f"  Dropout     : {self.dropout.p}",
            f"  LSTM 2      : {self.hidden_1} → {self.hidden_2} unidades",
            f"  Dense       : {self.hidden_2} → {self.num_classes} classes (softmax)",
            f"  Parâmetros  : {total_params:,} total | {trainable:,} treináveis",
        ]
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def build_model(
    cfg: MindFlowTrainingConfig = DEFAULT_CFG,
    input_dim: Optional[int] = None,
) -> MindFlowLSTM:
    """
    Constrói o modelo a partir da configuração.

    Parâmetros
    ----------
    cfg : configuração completa
    input_dim : sobrescreve cfg.features.vector_dim (usado quando PCA
                reduz a dimensão das features)
    """
    dim = input_dim if input_dim is not None else cfg.features.vector_dim
    model = MindFlowLSTM(
        input_dim=dim,
        hidden_1=cfg.model.lstm_hidden_1,
        hidden_2=cfg.model.lstm_hidden_2,
        num_classes=cfg.classes.num_classes,
        dropout=cfg.model.dropout,
    )
    logger.info("Modelo construído:\n%s", model.summary())
    return model


def load_model(
    path: Path,
    cfg: MindFlowTrainingConfig = DEFAULT_CFG,
    input_dim: Optional[int] = None,
    device: str = "cpu",
) -> MindFlowLSTM:
    """
    Carrega modelo salvo do disco (pesos congelados para inferência).

    Parâmetros
    ----------
    path : caminho para o arquivo .pt
    cfg  : configuração (define arquitetura)
    input_dim : necessário se PCA foi usado no treinamento
    device : "cpu" | "cuda"
    """
    model = build_model(cfg, input_dim=input_dim)
    state = torch.load(path, map_location=device, weights_only=True)
    model.load_state_dict(state)
    model.eval()
    logger.info("Modelo carregado de: %s (device=%s)", path, device)
    return model


# ---------------------------------------------------------------------------
# Smoke test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")

    print("=== Smoke test: MindFlowLSTM ===\n")
    model = build_model()
    print(model.summary())

    # Forward pass com batch sintético
    batch_size = 4
    x = torch.randn(batch_size, 30, 120)   # (batch, seq, features)
    logits = model(x)
    probs  = model.predict_proba(x)
    preds  = model.predict(x)

    print(f"\n  x.shape      : {x.shape}")
    print(f"  logits.shape : {logits.shape}")    # (4, 3)
    print(f"  probs.shape  : {probs.shape}")     # (4, 3)
    print(f"  probs sum    : {probs.sum(dim=-1)}")  # deve ser [1, 1, 1, 1]
    print(f"  preds        : {preds}")            # [0|1|2, ...]

    # Verifica que os pesos são treináveis
    total = sum(p.numel() for p in model.parameters())
    print(f"\n  Parâmetros totais: {total:,}")
    print("\n✅  Model OK")
