"""
training/config.py
==================
Configuração central do pipeline de treinamento do MindFlow AI.

Todos os hiperparâmetros em um único lugar — nenhum "magic number"
nos outros módulos. Para experimentar, altere apenas este arquivo.

Estrutura esperada do repositório:
    mindflow_extractor/          ← pacote do extrator (já pronto)
    training/                    ← este módulo
    outputs/
        features/                ← pares .npy + _metadata.json (saída do video_runner)
        training/                ← artefatos gerados por este módulo
    data/                        ← alternativa: CSV consolidado (opcional)

Referências metodológicas:
  - Arquitetura LSTM: MindFlow_Metodologia.pdf §4.1 decisão 8
  - Janela temporal 30 frames: idem
  - Divisão 60/20/20: idem, decisão 7
  - Normalização antes do SMOTE: idem, decisão 4
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Tuple


# ---------------------------------------------------------------------------
# Caminhos base
# ---------------------------------------------------------------------------

ROOT_DIR   = Path(__file__).resolve().parent.parent   # raiz do repositório
# Diretório onde o video_runner.py salva os pares .npy + _metadata.json
FEATURES_DIR   = ROOT_DIR / "outputs" / "features"
# Alternativa: CSV consolidado (gerado pelo dataset.py se solicitado)
FEATURES_CSV   = ROOT_DIR / "outputs" / "features" / "daisee_features.csv"
# Artefatos do treinamento
OUTPUT_DIR     = ROOT_DIR / "outputs" / "training"
SCALER_PATH    = OUTPUT_DIR / "scaler.joblib"
PCA_PATH       = OUTPUT_DIR / "pca.joblib"
MODEL_PATH     = OUTPUT_DIR / "lstm_mindflow.pt"
METRICS_PATH   = OUTPUT_DIR / "metrics.json"


# ---------------------------------------------------------------------------
# Features
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FeatureConfig:
    """Dimensões do vetor produzido pelo mindflow_extractor."""
    vector_dim:   int = 120   # total de features por frame (Early Fusion)
    sequence_len: int = 30    # frames por janela temporal (~1 segundo a 30fps)

    # Blocos para auditoria / SHAP por bloco (índices inclusivos)
    block_A: Tuple[int, int] = (0,   31)   # 32d — AUs faciais
    block_B: Tuple[int, int] = (32,  43)   # 12d — head pose
    block_C: Tuple[int, int] = (44,  67)   # 24d — gaze
    block_D: Tuple[int, int] = (68,  83)   # 16d — olhos/EAR
    block_E: Tuple[int, int] = (84,  91)   #  8d — boca/MAR
    block_F: Tuple[int, int] = (92,  115)  # 24d — postura
    block_G: Tuple[int, int] = (116, 119)  #  4d — qualidade


# ---------------------------------------------------------------------------
# Classes
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ClassConfig:
    """
    Mapeamento de rótulos.

    O DAiSEE anota engajamento em escala 0-3. Seguindo a literatura
    (e.g. Gupta et al. 2016), binarizamos em 3 classes funcionais:
      - 0 = engajado     (label DAiSEE 2 ou 3 → alto engajamento)
      - 1 = entediado    (label DAiSEE 0 ou 1 → baixo engajamento)
      - 2 = confuso      (label DAiSEE de confusão > 1)

    A decisão de mapeamento fica centralizada em dataset.py:
    função `daisee_label_to_class()`.
    """
    names:       Tuple[str, ...] = ("engajado", "entediado", "confuso")
    num_classes: int = 3


# ---------------------------------------------------------------------------
# Pré-processamento
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class PreprocessConfig:
    scaler:                  str   = "standard"   # "standard"|"minmax"|"robust"
    smote_k_neighbors:       int   = 5
    smote_random_state:      int   = 42
    use_pca:                 bool  = False
    pca_variance_threshold:  float = 0.95
    pca_random_state:        int   = 42
    train_ratio:             float = 0.60
    val_ratio:               float = 0.20
    test_ratio:              float = 0.20
    split_random_state:      int   = 42
    # True → split por subject_id (correto para evitar data leakage)
    subject_aware_split:     bool  = True
    # Passo da janela deslizante ao construir sequências
    # sequence_len // 2 = 50% de overlap (padrão)
    sequence_stride:         int   = 15


# ---------------------------------------------------------------------------
# Arquitetura
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ModelConfig:
    """
    LSTM conforme MindFlow_Metodologia.pdf §4.1 decisão 8:
        Input(30, D) → LSTM(128) → Dropout(0.3) → LSTM(64) → Dense(3) → Softmax
    """
    lstm_hidden_1: int   = 128
    lstm_hidden_2: int   = 64
    dropout:       float = 0.3


# ---------------------------------------------------------------------------
# Treinamento
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class TrainConfig:
    optimizer:           str   = "adam"
    learning_rate:       float = 1e-3
    weight_decay:        float = 1e-4
    use_lr_scheduler:    bool  = True
    lr_patience:         int   = 5
    lr_factor:           float = 0.5
    max_epochs:          int   = 100
    batch_size:          int   = 64
    early_stop_patience: int   = 15
    seed:                int   = 42
    device:              str   = "auto"


# ---------------------------------------------------------------------------
# Avaliação
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class EvalConfig:
    primary_metric: str            = "f1_macro"
    report_metrics: Tuple[str, ...] = (
        "accuracy", "f1_macro", "f1_weighted",
        "precision_macro", "recall_macro", "confusion_matrix",
    )
    save_history: bool = True


# ---------------------------------------------------------------------------
# Config agregada
# ---------------------------------------------------------------------------

@dataclass
class MindFlowTrainingConfig:
    """
    Ponto de entrada único. Use em todos os módulos:

        from training.config import MindFlowTrainingConfig
        cfg = MindFlowTrainingConfig()
    """
    features:   FeatureConfig   = field(default_factory=FeatureConfig)
    classes:    ClassConfig     = field(default_factory=ClassConfig)
    preprocess: PreprocessConfig = field(default_factory=PreprocessConfig)
    model:      ModelConfig     = field(default_factory=ModelConfig)
    train:      TrainConfig     = field(default_factory=TrainConfig)
    eval:       EvalConfig      = field(default_factory=EvalConfig)


DEFAULT_CFG = MindFlowTrainingConfig()


if __name__ == "__main__":
    cfg = MindFlowTrainingConfig()
    print("=== MindFlow Training Config ===")
    print(f"  vector_dim    : {cfg.features.vector_dim}")
    print(f"  sequence_len  : {cfg.features.sequence_len}")
    print(f"  num_classes   : {cfg.classes.num_classes}")
    print(f"  class_names   : {cfg.classes.names}")
    print(f"  LSTM arch     : {cfg.model.lstm_hidden_1}→{cfg.model.lstm_hidden_2}→Dense({cfg.classes.num_classes})")
    print(f"  split         : {cfg.preprocess.train_ratio}/{cfg.preprocess.val_ratio}/{cfg.preprocess.test_ratio}")
    print(f"  subject_split : {cfg.preprocess.subject_aware_split}")
    print(f"  features_dir  : {FEATURES_DIR}")
    print(f"  model_path    : {MODEL_PATH}")
    print("\n✅  Config OK")
