"""
training/train.py
=================
Loop de treinamento do MindFlow AI.

Funcionalidades:
  - Treinamento com Adam + CrossEntropyLoss (com pesos por classe)
  - Early stopping no val_loss (evita overfitting sem over-tuning)
  - LR scheduler (ReduceLROnPlateau) para convergência suave
  - Checkpoint do melhor modelo (menor val_loss)
  - Histórico de métricas por época (loss, accuracy, F1-macro)
  - Logging estruturado para acompanhamento durante o treino
  - Seed para reprodutibilidade completa

Uso:
    from training.train import train_model
    history = train_model()
"""

from __future__ import annotations

import json
import logging
import random
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.optim import Adam
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader
from sklearn.metrics import f1_score

from training.config import MindFlowTrainingConfig, DEFAULT_CFG, MODEL_PATH, OUTPUT_DIR
from training.dataset import MindFlowDataset, load_dataset
from training.model import MindFlowLSTM, build_model
from training.preprocessing import preprocess_pipeline

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Reprodutibilidade
# ---------------------------------------------------------------------------

def set_seed(seed: int) -> None:
    """Fixa a semente em todos os geradores de aleatoriedade."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ---------------------------------------------------------------------------
# Device
# ---------------------------------------------------------------------------

def resolve_device(device_str: str) -> torch.device:
    if device_str == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(device_str)
    logger.info("Device: %s", device)
    return device


# ---------------------------------------------------------------------------
# Epoch runners
# ---------------------------------------------------------------------------

def _run_epoch(
    model:     MindFlowLSTM,
    loader:    DataLoader,
    criterion: nn.Module,
    optimizer: Optional[torch.optim.Optimizer],
    device:    torch.device,
    phase:     str,
) -> Tuple[float, float, float]:
    """
    Executa uma época de treino ou validação.

    Retorna
    -------
    loss_mean, accuracy, f1_macro
    """
    is_train = (phase == "train")
    model.train() if is_train else model.eval()

    total_loss = 0.0
    all_preds:  List[int] = []
    all_labels: List[int] = []

    context = torch.enable_grad if is_train else torch.no_grad

    with context():
        for X_batch, y_batch in loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)

            logits = model(X_batch)
            loss   = criterion(logits, y_batch)

            if is_train:
                optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()

            total_loss += loss.item() * len(y_batch)
            preds = logits.argmax(dim=-1)
            all_preds.extend(preds.cpu().numpy().tolist())
            all_labels.extend(y_batch.cpu().numpy().tolist())

    n = len(all_labels)
    loss_mean = total_loss / n
    accuracy  = sum(p == l for p, l in zip(all_preds, all_labels)) / n
    f1_macro  = f1_score(all_labels, all_preds, average="macro", zero_division=0)

    return loss_mean, accuracy, f1_macro


# ---------------------------------------------------------------------------
# Loop principal
# ---------------------------------------------------------------------------

def train_model(
    cfg:           MindFlowTrainingConfig = DEFAULT_CFG,
    use_synthetic: bool = False,
    save_model:    bool = True,
) -> Dict[str, List]:
    """
    Treina o MindFlowLSTM do início ao fim.

    Parâmetros
    ----------
    cfg : configuração completa
    use_synthetic : forçar dados sintéticos (ignorado se CSV não existe)
    save_model : salvar o melhor checkpoint em disco

    Retorna
    -------
    history : dicionário com listas de métricas por época
    """
    set_seed(cfg.train.seed)
    device = resolve_device(cfg.train.device)

    # ----------------------------------------------------------------
    # 1. Dados
    # ----------------------------------------------------------------
    logger.info("Carregando dataset...")
    X, y, subjects = load_dataset(cfg=cfg, use_synthetic=use_synthetic)

    logger.info("Pré-processando...")
    (X_train, y_train, X_val, y_val, X_test, y_test), artifacts = preprocess_pipeline(
        X, y, subjects, cfg=cfg, save_artifacts=save_model
    )

    # ----------------------------------------------------------------
    # 2. DataLoaders
    # ----------------------------------------------------------------
    ds_train = MindFlowDataset(X_train, y_train)
    ds_val   = MindFlowDataset(X_val,   y_val)

    loader_train = DataLoader(
        ds_train,
        batch_size=cfg.train.batch_size,
        shuffle=True,
        num_workers=0,
        pin_memory=(device.type == "cuda"),
    )
    loader_val = DataLoader(
        ds_val,
        batch_size=cfg.train.batch_size,
        shuffle=False,
        num_workers=0,
    )

    # ----------------------------------------------------------------
    # 3. Modelo
    # ----------------------------------------------------------------
    input_dim = X_train.shape[2]   # 120 sem PCA, n_components com PCA
    model = build_model(cfg, input_dim=input_dim).to(device)

    # ----------------------------------------------------------------
    # 4. Loss com pesos por classe (lida com desbalanço residual)
    # ----------------------------------------------------------------
    class_weights = ds_train.compute_class_weights().to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights)
    logger.info("Pesos das classes no loss: %s", class_weights.cpu().tolist())

    # ----------------------------------------------------------------
    # 5. Otimizador e scheduler
    # ----------------------------------------------------------------
    optimizer = Adam(
        model.parameters(),
        lr=cfg.train.learning_rate,
        weight_decay=cfg.train.weight_decay,
    )
    scheduler = ReduceLROnPlateau(
        optimizer,
        mode="min",
        patience=cfg.train.lr_patience,
        factor=cfg.train.lr_factor,
    )

    # ----------------------------------------------------------------
    # 6. Loop de épocas
    # ----------------------------------------------------------------
    history: Dict[str, List] = {
        "train_loss": [], "train_acc": [], "train_f1": [],
        "val_loss":   [], "val_acc":   [], "val_f1":   [],
        "lr": [],
    }

    best_val_loss   = float("inf")
    epochs_no_improve = 0
    best_epoch      = 0

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    logger.info("=" * 60)
    logger.info("INICIANDO TREINAMENTO — %d épocas máx.", cfg.train.max_epochs)
    logger.info("=" * 60)

    for epoch in range(1, cfg.train.max_epochs + 1):
        # Treino
        t_loss, t_acc, t_f1 = _run_epoch(
            model, loader_train, criterion, optimizer, device, "train"
        )
        # Validação
        v_loss, v_acc, v_f1 = _run_epoch(
            model, loader_val, criterion, None, device, "val"
        )

        current_lr = optimizer.param_groups[0]["lr"]
        scheduler.step(v_loss)

        history["train_loss"].append(t_loss)
        history["train_acc"].append(t_acc)
        history["train_f1"].append(t_f1)
        history["val_loss"].append(v_loss)
        history["val_acc"].append(v_acc)
        history["val_f1"].append(v_f1)
        history["lr"].append(current_lr)

        logger.info(
            "Época %3d/%d | "
            "train loss=%.4f acc=%.3f f1=%.3f | "
            "val loss=%.4f acc=%.3f f1=%.3f | lr=%.2e",
            epoch, cfg.train.max_epochs,
            t_loss, t_acc, t_f1,
            v_loss, v_acc, v_f1,
            current_lr,
        )

        # Checkpoint
        if v_loss < best_val_loss:
            best_val_loss = v_loss
            best_epoch    = epoch
            epochs_no_improve = 0
            if save_model:
                torch.save(model.state_dict(), MODEL_PATH)
                logger.info("  💾 Checkpoint salvo (val_loss=%.4f)", best_val_loss)
        else:
            epochs_no_improve += 1

        # Early stopping
        if epochs_no_improve >= cfg.train.early_stop_patience:
            logger.info(
                "⏹  Early stopping na época %d (melhor: época %d, val_loss=%.4f)",
                epoch, best_epoch, best_val_loss,
            )
            break

    logger.info("=" * 60)
    logger.info("Treinamento concluído. Melhor época: %d", best_epoch)

    # ----------------------------------------------------------------
    # 7. Salva histórico
    # ----------------------------------------------------------------
    if save_model and cfg.eval.save_history:
        history_path = OUTPUT_DIR / "training_history.json"
        with open(history_path, "w") as f:
            json.dump(history, f, indent=2)
        logger.info("Histórico salvo em: %s", history_path)

    # Retorna também os dados de teste para o evaluate.py
    history["_test_data"] = (X_test, y_test)
    history["_model"] = model
    history["_artifacts"] = artifacts
    history["_best_epoch"] = best_epoch

    return history


# ---------------------------------------------------------------------------
# Smoke test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s | %(message)s",
    )

    # Config rápida para smoke test (menos épocas)
    cfg = DEFAULT_CFG.__class__()
    # Sobrescreve epochs e patience para teste rápido
    from dataclasses import replace
    fast_train = replace(cfg.train, max_epochs=5, early_stop_patience=10)
    cfg = replace(cfg, train=fast_train)

    print("=== Smoke test: train_model (5 épocas, dados sintéticos) ===\n")
    history = train_model(cfg=cfg, use_synthetic=True, save_model=False)

    print(f"\n  Épocas rodadas  : {len(history['train_loss'])}")
    print(f"  Melhor época    : {history['_best_epoch']}")
    print(f"  Último val_loss : {history['val_loss'][-1]:.4f}")
    print(f"  Último val_f1   : {history['val_f1'][-1]:.4f}")
    print("\n✅  Train OK")
