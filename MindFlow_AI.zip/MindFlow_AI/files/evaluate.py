"""
training/evaluate.py
====================
Avaliação do modelo treinado no conjunto de teste do MindFlow AI.

Métricas reportadas (conforme prática padrão na literatura de AER):
  - Accuracy
  - F1-macro (métrica primária — trata classes igualmente)
  - F1-weighted (considera desbalanço real do teste)
  - Precision e Recall por classe
  - Matriz de confusão
  - Relatório completo por classe (sklearn classification_report)

IMPORTANTE: este módulo usa APENAS o conjunto de teste, que deve ser
mantido intocado durante todo o desenvolvimento. Rodá-lo antes do
treinamento final contamina os resultados reportados no TCC.

Referência de baseline DAiSEE:
  Gupta et al. (2016) reportam ~60-65% accuracy com CNN end-to-end.
  O MindFlow visa superar esse baseline com a abordagem de features
  interpretáveis + LSTM temporal.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)

from training.config import MindFlowTrainingConfig, DEFAULT_CFG, MODEL_PATH, METRICS_PATH, OUTPUT_DIR
from training.dataset import MindFlowDataset, LABEL_MAP
from training.model import MindFlowLSTM, build_model, load_model

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Inferência em batch
# ---------------------------------------------------------------------------

def run_inference(
    model:  MindFlowLSTM,
    X:      np.ndarray,
    device: torch.device,
    batch_size: int = 128,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Roda inferência em X e retorna predições e probabilidades.

    Parâmetros
    ----------
    model : modelo treinado (em eval mode)
    X : (N, seq_len, features) — já normalizado (e com PCA se aplicável)
    device : device de inferência
    batch_size : tamanho do batch para não estourar memória

    Retorna
    -------
    preds : (N,) — classe predita
    probs : (N, num_classes) — probabilidades softmax
    """
    model.eval()
    all_preds = []
    all_probs = []

    n = len(X)
    with torch.no_grad():
        for start in range(0, n, batch_size):
            end   = min(start + batch_size, n)
            x_bat = torch.from_numpy(X[start:end]).float().to(device)
            logits = model(x_bat)
            probs  = torch.softmax(logits, dim=-1)
            preds  = probs.argmax(dim=-1)
            all_preds.extend(preds.cpu().numpy().tolist())
            all_probs.extend(probs.cpu().numpy().tolist())

    return np.array(all_preds), np.array(all_probs)


# ---------------------------------------------------------------------------
# Cálculo de métricas
# ---------------------------------------------------------------------------

def compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Tuple[str, ...] = ("engajado", "entediado", "confuso"),
) -> Dict:
    """
    Calcula o conjunto completo de métricas para reporte no TCC.

    Parâmetros
    ----------
    y_true : rótulos verdadeiros
    y_pred : predições do modelo
    class_names : nomes das classes para o relatório

    Retorna
    -------
    dict com todas as métricas serializável em JSON
    """
    acc      = accuracy_score(y_true, y_pred)
    f1_mac   = f1_score(y_true, y_pred, average="macro",    zero_division=0)
    f1_wei   = f1_score(y_true, y_pred, average="weighted", zero_division=0)
    prec_mac = precision_score(y_true, y_pred, average="macro",    zero_division=0)
    rec_mac  = recall_score(y_true, y_pred,    average="macro",    zero_division=0)
    cm       = confusion_matrix(y_true, y_pred).tolist()

    # Por classe
    per_class = {}
    for i, name in enumerate(class_names):
        mask = (y_true == i)
        per_class[name] = {
            "support":   int(mask.sum()),
            "precision": float(precision_score(y_true, y_pred, labels=[i], average="macro", zero_division=0)),
            "recall":    float(recall_score(   y_true, y_pred, labels=[i], average="macro", zero_division=0)),
            "f1":        float(f1_score(       y_true, y_pred, labels=[i], average="macro", zero_division=0)),
        }

    report_str = classification_report(
        y_true, y_pred,
        target_names=list(class_names),
        zero_division=0,
    )

    metrics = {
        "accuracy":         round(float(acc),      4),
        "f1_macro":         round(float(f1_mac),   4),
        "f1_weighted":      round(float(f1_wei),   4),
        "precision_macro":  round(float(prec_mac), 4),
        "recall_macro":     round(float(rec_mac),  4),
        "confusion_matrix": cm,
        "per_class":        per_class,
        "classification_report": report_str,
    }
    return metrics


# ---------------------------------------------------------------------------
# Exibição formatada
# ---------------------------------------------------------------------------

def print_metrics(metrics: Dict) -> None:
    """Exibe métricas de forma legível no console."""
    sep = "=" * 55
    print(f"\n{sep}")
    print("  RESULTADOS NO CONJUNTO DE TESTE — MindFlow AI")
    print(sep)
    print(f"  Accuracy       : {metrics['accuracy']:.4f}  ({metrics['accuracy']*100:.1f}%)")
    print(f"  F1-macro       : {metrics['f1_macro']:.4f}  ← métrica primária")
    print(f"  F1-weighted    : {metrics['f1_weighted']:.4f}")
    print(f"  Precision-macro: {metrics['precision_macro']:.4f}")
    print(f"  Recall-macro   : {metrics['recall_macro']:.4f}")
    print(f"\n  Baseline DAiSEE (Gupta et al. 2016): ~0.62 accuracy")
    delta = metrics['accuracy'] - 0.62
    symbol = "▲" if delta >= 0 else "▼"
    print(f"  Delta vs baseline: {symbol} {abs(delta):.4f}")
    print(f"\n{sep}")
    print("  Por classe:")
    for name, stats in metrics["per_class"].items():
        print(
            f"    {name:12s}: prec={stats['precision']:.3f}  "
            f"rec={stats['recall']:.3f}  f1={stats['f1']:.3f}  "
            f"n={stats['support']}"
        )
    print(f"\n  Matriz de Confusão:")
    print(f"  (linhas=real, colunas=predito)")
    class_names = list(metrics["per_class"].keys())
    header = "           " + "  ".join(f"{n[:6]:>6}" for n in class_names)
    print(f"  {header}")
    for i, (row, name) in enumerate(zip(metrics["confusion_matrix"], class_names)):
        row_str = "  ".join(f"{v:6d}" for v in row)
        print(f"  {name[:10]:10s}  {row_str}")
    print(sep)


# ---------------------------------------------------------------------------
# Função principal de avaliação
# ---------------------------------------------------------------------------

def evaluate_model(
    model:    Optional[MindFlowLSTM] = None,
    X_test:   Optional[np.ndarray]   = None,
    y_test:   Optional[np.ndarray]   = None,
    cfg:      MindFlowTrainingConfig  = DEFAULT_CFG,
    save:     bool = True,
) -> Dict:
    """
    Avalia o modelo no conjunto de teste e salva as métricas.

    Pode ser chamada de duas formas:
      1. Passando model, X_test, y_test diretamente (do train.py)
      2. Sem argumentos: carrega o modelo salvo em disco e roda sobre
         dados sintéticos (útil para verificar que o checkpoint está OK)

    Parâmetros
    ----------
    model  : modelo treinado (None → carrega de MODEL_PATH)
    X_test : features de teste já pré-processadas
    y_test : rótulos de teste
    cfg    : configuração
    save   : persistir métricas em METRICS_PATH
    """
    device = torch.device("cpu")   # teste sempre em CPU para determinismo

    if model is None:
        if not MODEL_PATH.exists():
            raise FileNotFoundError(
                f"Modelo não encontrado em {MODEL_PATH}. "
                "Execute train.py primeiro."
            )
        model = load_model(MODEL_PATH, cfg=cfg, device="cpu")

    if X_test is None or y_test is None:
        logger.warning("X_test/y_test não fornecidos — usando dados sintéticos para diagnóstico.")
        from training.dataset import load_dataset
        from training.preprocessing import preprocess_pipeline
        X, y, subjects = load_dataset(cfg=cfg, use_synthetic=True)
        (_, _, _, _, X_test, y_test), _ = preprocess_pipeline(
            X, y, subjects, cfg=cfg, save_artifacts=False
        )

    logger.info("Rodando inferência em %d amostras de teste...", len(X_test))
    y_pred, y_probs = run_inference(model, X_test, device, batch_size=cfg.train.batch_size)

    metrics = compute_metrics(y_pred=y_pred, y_true=y_test, class_names=cfg.classes.names)

    print_metrics(metrics)

    if save:
        METRICS_PATH.parent.mkdir(parents=True, exist_ok=True)
        # Remove o campo verboso antes de salvar
        metrics_to_save = {k: v for k, v in metrics.items() if k != "classification_report"}
        with open(METRICS_PATH, "w") as f:
            json.dump(metrics_to_save, f, indent=2)
        logger.info("Métricas salvas em: %s", METRICS_PATH)

        # Salva o relatório completo separado (mais legível no TCC)
        report_path = OUTPUT_DIR / "classification_report.txt"
        with open(report_path, "w") as f:
            f.write(metrics["classification_report"])
        logger.info("Relatório de classificação salvo em: %s", report_path)

    return metrics


# ---------------------------------------------------------------------------
# Smoke test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")

    print("=== Smoke test: evaluate (treina 3 épocas + avalia) ===\n")

    # Treina rapidamente
    from dataclasses import replace
    from training.train import train_model

    cfg = DEFAULT_CFG.__class__()
    fast_train = replace(cfg.train, max_epochs=3, early_stop_patience=10)
    cfg = replace(cfg, train=fast_train)

    history = train_model(cfg=cfg, use_synthetic=True, save_model=False)

    # Avalia no teste
    model   = history["_model"]
    X_test, y_test = history["_test_data"]

    metrics = evaluate_model(
        model=model,
        X_test=X_test,
        y_test=y_test,
        cfg=cfg,
        save=False,
    )

    assert "f1_macro" in metrics
    assert "confusion_matrix" in metrics
    print("\n✅  Evaluate OK")
