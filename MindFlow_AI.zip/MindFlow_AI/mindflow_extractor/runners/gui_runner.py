"""
mindflow_extractor/runners/gui_runner.py
========================================
Interface gráfica completa do MindFlow AI — PyQt5 + OpenCV.

Uso:
    python -m mindflow_extractor.runners.gui_runner
    python run.py   (se configurado)
"""
from __future__ import annotations

import os
import sys
import time
from collections import deque
from pathlib import Path
from typing import Optional, List

# ── Importa cv2 PRIMEIRO (ele seta QT_PLUGIN_PATH para seus plugins) ─────────
# Depois limpamos e apontamos para os plugins do PyQt5.
# Esta ordem é obrigatória para evitar o crash "xcb plugin not found".
import cv2  # noqa: E402 — deve vir antes do PyQt5
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Limpa o path do cv2 e aponta para o PyQt5
os.environ.pop("QT_PLUGIN_PATH", None)
_pyqt5_plugins = (
    ROOT / ".venv" / "lib" / "python3.12"
    / "site-packages" / "PyQt5" / "Qt5" / "plugins"
)
if _pyqt5_plugins.exists():
    os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = str(_pyqt5_plugins)

from PyQt5.QtCore import Qt, QThread, QRect, pyqtSignal  # noqa: E402
from PyQt5.QtGui import QImage, QPixmap, QFont, QColor, QPainter, QPen  # noqa: E402
from PyQt5.QtWidgets import (  # noqa: E402
    QApplication, QMainWindow, QWidget, QDialog,
    QHBoxLayout, QVBoxLayout, QGridLayout,
    QLabel, QPushButton, QCheckBox, QComboBox,
    QGroupBox, QFrame, QSpinBox, QFileDialog,
    QDialogButtonBox, QProgressBar
)

# ─── Constantes ──────────────────────────────────────────────────────────────

TASK_NAMES    = ["engagement", "boredom", "confusion", "frustration"]
TASK_DISPLAY  = ["Engajamento", "Tédio", "Confusão", "Frustração"]
LEVEL_LABELS  = ["Muito Baixo", "Baixo", "Alto", "Muito Alto"]

TASK_COLORS = [
    "#00E676",   # verde
    "#FF9800",   # laranja
    "#CE93D8",   # roxo
    "#F44336",   # vermelho
]

# ── Paleta — Liquid Glass Light (Golden) ──────────────────────────────────
BG_GRAD_TOP  = "#FFFBEB"   # creme dourado muito claro
BG_GRAD_BTM  = "#F9FAFB"   # cinza branco limpo
GLASS_BG     = "rgba(255,255,255,160)"
GLASS_BORDER = "rgba(255,255,255,220)"
TEXT_CLR     = "#1C1917"   # stone-900
MUTED_CLR    = "#78716C"   # stone-500
ACCENT       = "#B8860B"   # dark goldenrod
ACCENT_LIGHT = "#D4AF37"   # metallic gold
BORDER_CLR   = "rgba(184,134,11,35)"

STYLESHEET = """
QMainWindow, QDialog, QWidget {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #FFFBEB, stop:1 #F9FAFB);
    color: #1C1917;
    font-family: 'Inter', 'Ubuntu', 'Segoe UI', sans-serif;
}
QGroupBox {
    background: rgba(255,255,255,150);
    border: 1.5px solid rgba(255,255,255,200);
    border-radius: 16px;
    margin-top: 14px;
    padding-top: 22px;
    padding-bottom: 10px;
    padding-left: 12px;
    padding-right: 12px;
    font-size: 11px;
    font-weight: bold;
    color: #78716C;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 14px;
    padding: 0 6px;
    color: #B8860B;
    font-size: 11px;
    font-weight: bold;
    letter-spacing: 1px;
    text-transform: uppercase;
}
QPushButton {
    background: rgba(255,255,255,180);
    border: 1.5px solid rgba(184,134,11,60);
    border-radius: 10px;
    color: #1C1917;
    padding: 9px 18px;
    font-size: 12px;
    font-weight: 500;
}
QPushButton:hover {
    background: rgba(212,175,55,20);
    border-color: #D4AF37;
    color: #B8860B;
}
QPushButton:pressed {
    background: rgba(212,175,55,35);
}
QPushButton#accent {
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
        stop:0 #B8860B, stop:1 #D4AF37);
    border: none;
    color: white;
    font-weight: bold;
    border-radius: 10px;
}
QPushButton#accent:hover {
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
        stop:0 #C9971A, stop:1 #E0C050);
}
QPushButton#danger {
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
        stop:0 #F43F5E, stop:1 #FB7185);
    border: none;
    color: white;
    border-radius: 10px;
}
QCheckBox { color: #1C1917; spacing: 8px; font-size: 12px; }
QCheckBox::indicator {
    width: 18px; height: 18px;
    border: 1.5px solid rgba(184,134,11,100);
    border-radius: 5px;
    background: rgba(255,255,255,180);
}
QCheckBox::indicator:checked {
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
        stop:0 #B8860B, stop:1 #D4AF37);
    border-color: #D4AF37;
}
QComboBox {
    background: rgba(255,255,255,200);
    border: 1.5px solid rgba(184,134,11,60);
    border-radius: 10px;
    color: #1C1917;
    padding: 7px 12px;
    font-size: 12px;
    min-height: 20px;
}
QComboBox::drop-down { border: none; width: 24px; }
QComboBox QAbstractItemView {
    background: rgba(255,255,255,240);
    border: 1px solid rgba(184,134,11,60);
    border-radius: 8px;
    color: #1C1917;
    selection-background-color: rgba(212,175,55,30);
    selection-color: #B8860B;
}
QLabel { color: #1C1917; }
QSpinBox {
    background: rgba(255,255,255,200);
    border: 1.5px solid rgba(184,134,11,60);
    border-radius: 10px;
    color: #1C1917;
    padding: 7px 10px;
    font-size: 12px;
}
QProgressBar {
    background: rgba(231,224,213,160);
    border: none;
    border-radius: 6px;
    text-align: center;
    color: #57534E;
    font-size: 10px;
    font-weight: bold;
    height: 16px;
}
QProgressBar::chunk {
    border-radius: 6px;
}
QFrame[frameShape="4"] { color: rgba(184,134,11,50); }
QScrollBar:vertical { width: 6px; background: transparent; }
QScrollBar::handle:vertical {
    background: rgba(184,134,11,80);
    border-radius: 3px;
    min-height: 20px;
}
"""


# ─── Gauge circular ──────────────────────────────────────────────────────────

class GaugeWidget(QWidget):
    """Gauge circular com estética liquid glass."""

    def __init__(self, title: str, color: str, parent=None):
        super().__init__(parent)
        self.title  = title
        self.color  = QColor(color)
        self._value = 0.0
        self._level = "—"
        self.setFixedSize(140, 150)
        self.setAttribute(Qt.WA_TranslucentBackground)

    def set_value(self, prob: float, level_label: str):
        self._value = max(0.0, min(1.0, prob))
        self._level = level_label
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        cx, cy = self.width() // 2, self.height() // 2 - 8
        r = 50

        # Fundo glass (círculo branco translúcido com sombra suave)
        p.setPen(Qt.NoPen)
        shadow = QColor(100, 100, 200, 18)
        for i in range(3):
            p.setBrush(shadow)
            p.drawEllipse(cx - r - i, cy - r - i, (r + i) * 2, (r + i) * 2)

        glass_bg = QColor(255, 255, 255, 200)
        p.setBrush(glass_bg)
        p.drawEllipse(cx - r, cy - r, r * 2, r * 2)

        # Borda glass (anel branco brilhante)
        border_pen = QPen(QColor(255, 255, 255, 230), 2)
        p.setPen(border_pen)
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(cx - r + 1, cy - r + 1, (r - 1) * 2, (r - 1) * 2)

        # Arco de fundo (trilha cinza claro)
        track_pen = QPen(QColor(226, 232, 240, 200), 7, Qt.SolidLine, Qt.RoundCap)
        p.setPen(track_pen)
        p.drawArc(cx - r + 8, cy - r + 8, (r - 8) * 2, (r - 8) * 2, 225 * 16, -270 * 16)

        # Arco de valor (gradiente da cor principal)
        if self._value > 0:
            arc_color = QColor(self.color)
            arc_color.setAlpha(230)
            arc_pen = QPen(arc_color, 7, Qt.SolidLine, Qt.RoundCap)
            p.setPen(arc_pen)
            span = int(-270 * 16 * self._value)
            p.drawArc(cx - r + 8, cy - r + 8, (r - 8) * 2, (r - 8) * 2, 225 * 16, span)

        # Percentual central — grande e bold
        p.setPen(QPen(self.color))
        p.setFont(QFont("Inter", 15, QFont.Bold))
        p.drawText(QRect(cx - r, cy - 16, r * 2, 32), Qt.AlignCenter, f"{int(self._value * 100)}%")

        # Rótulo do nível — pequeno abaixo
        p.setPen(QPen(QColor(100, 116, 139)))   # slate-500
        p.setFont(QFont("Inter", 7, QFont.Normal))
        p.drawText(QRect(cx - r, cy + 14, r * 2, 18), Qt.AlignCenter, self._level)

        # Título da dimensão — colorido na base
        p.setPen(QPen(self.color))
        p.setFont(QFont("Inter", 8, QFont.Bold))
        p.drawText(QRect(0, self.height() - 22, self.width(), 20), Qt.AlignCenter, self.title)


# ─── Worker Thread ────────────────────────────────────────────────────────────

class InferenceWorker(QThread):
    frame_ready  = pyqtSignal(np.ndarray, list, int, float)  # frame, probs_list, buffer_len, fps
    error        = pyqtSignal(str)

    def __init__(
        self, camera_idx: int, run_dir: Path, seq_len: int = 30
    ):
        super().__init__()
        self.camera_idx  = camera_idx
        self.run_dir     = run_dir
        self.seq_len     = seq_len
        self.seq_len     = seq_len
        self._running    = True

        # Configurações de overlay (thread-safe via atributos)
        self.show_face   = True
        self.show_pose   = True
        self.infer_every = 15

    def stop(self):
        self._running = False

    def run(self):
        try:
            self._run()
        except Exception as e:
            self.error.emit(str(e))

    def _run(self):
        import joblib, torch
        from training.model import MindFlowLSTM
        from training.config import MindFlowTrainingConfig
        from mindflow_extractor.pipeline import MindFlowPipeline

        cfg   = MindFlowTrainingConfig()
        scaler_path = self.run_dir / "scaler.joblib"
        pca_path = self.run_dir / "pca.joblib"
        model_path = self.run_dir / "lstm_mindflow.pt"
        
        scaler = joblib.load(scaler_path)
        pca    = joblib.load(pca_path)
        dim    = pca.n_components_

        # Detecta a arquitetura do modelo automaticamente a partir dos pesos salvos
        # Evita erro de size_mismatch quando o config foi alterado após o treino
        state    = torch.load(model_path, map_location="cpu", weights_only=True)
        hidden_1 = state["lstm1.weight_hh_l0"].shape[0] // 4
        hidden_2 = state["lstm2.weight_hh_l0"].shape[0] // 4

        model = MindFlowLSTM(input_dim=dim,
                             hidden_1=hidden_1,
                             hidden_2=hidden_2,
                             dropout=0.0)
        model.load_state_dict(state)
        model.eval()

        cap = cv2.VideoCapture(self.camera_idx)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH,  960)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 540)
        cap.set(cv2.CAP_PROP_FPS, 30)

        buffer: deque = deque(maxlen=self.seq_len * 4)
        probs_list = None
        frame_count = 0
        last_infer  = -999
        t_prev = time.perf_counter()

        try:
            import mediapipe as mp
            _mp_drawing = mp.solutions.drawing_utils
            _mp_fm      = mp.solutions.face_mesh
            _mp_pose    = mp.solutions.pose
            _FACE_CONN  = _mp_fm.FACEMESH_CONTOURS
            _POSE_CONN  = _mp_pose.POSE_CONNECTIONS
        except Exception:
            _mp_drawing = None

        def _predict(buf):
            if len(buf) < self.seq_len:
                return None
            w = np.nan_to_num(np.array(list(buf)[-self.seq_len:], dtype=np.float32))
            wf = scaler.transform(w.reshape(-1, w.shape[1]))
            wf = pca.transform(wf).reshape(1, self.seq_len, -1)
            x  = torch.from_numpy(wf).float()
            with torch.no_grad():
                lgs = model(x)
                return [torch.softmax(l, -1).squeeze().numpy() for l in lgs]

        with MindFlowPipeline() as pipe:
            while self._running:
                ret, frame = cap.read()
                if not ret:
                    break
                frame = cv2.flip(frame, 1)
                rgb   = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                t = time.perf_counter()
                fps = 1.0 / max(t - t_prev, 1e-6)
                t_prev = t

                result = pipe.process(rgb, frame_idx=frame_count, timestamp_ms=t * 1000)
                buffer.append(result.vector.copy())

                if frame_count - last_infer >= self.infer_every:
                    p = _predict(buffer)
                    if p is not None:
                        probs_list = p
                    last_infer = frame_count

                # Overlays no frame
                if _mp_drawing:
                    if self.show_face and result.mp_face_landmarks:
                        _mp_drawing.draw_landmarks(
                            frame, result.mp_face_landmarks, _FACE_CONN,
                            _mp_drawing.DrawingSpec(color=(0, 220, 100), thickness=1, circle_radius=1),
                            _mp_drawing.DrawingSpec(color=(0, 200, 255), thickness=1),
                        )
                    if self.show_pose and result.mp_pose_landmarks:
                        _mp_drawing.draw_landmarks(
                            frame, result.mp_pose_landmarks, _POSE_CONN,
                            _mp_drawing.DrawingSpec(color=(255, 180, 0), thickness=3, circle_radius=3),
                            _mp_drawing.DrawingSpec(color=(0, 180, 255), thickness=2),
                        )

                self.frame_ready.emit(
                    cv2.cvtColor(frame, cv2.COLOR_BGR2RGB),
                    probs_list if probs_list else [],
                    len(buffer),
                    fps,
                )
                frame_count += 1

        cap.release()


# ─── Tela de Configuração ─────────────────────────────────────────────────────

class LaunchDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("MindFlow AI — Configurações")
        self.setMinimumSize(480, 420)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.setContentsMargins(24, 24, 24, 24)

        # Header
        title = QLabel("🧠 MindFlow AI")
        title.setFont(QFont("Segoe UI", 20, QFont.Bold))
        title.setStyleSheet(f"color: {ACCENT};")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        sub = QLabel("Detecção de Estados Cognitivos em Tempo Real")
        sub.setStyleSheet(f"color: {MUTED_CLR}; font-size: 12px;")
        sub.setAlignment(Qt.AlignCenter)
        layout.addWidget(sub)

        line = QFrame(); line.setFrameShape(QFrame.HLine)
        layout.addWidget(line)

        # Câmera
        cam_box = QGroupBox("Câmera")
        cam_layout = QHBoxLayout(cam_box)
        cam_layout.addWidget(QLabel("Índice:"))
        self.camera_spin = QSpinBox()
        self.camera_spin.setRange(0, 9)
        self.camera_spin.setValue(0)
        cam_layout.addWidget(self.camera_spin)
        cam_layout.addStretch()
        layout.addWidget(cam_box)

        # Modelo (Selecionado por Run)
        model_box = QGroupBox("Modelo (Data/Hora)")
        model_layout = QHBoxLayout(model_box)
        
        self.model_combo = QComboBox()
        self.model_combo.setStyleSheet("padding: 4px;")
        
        runs_dir = ROOT / "outputs" / "training" / "runs"
        self.runs = []
        if runs_dir.exists():
            # Pega as pastas ordenadas de forma reversa (mais recente primeiro)
            self.runs = sorted([d for d in runs_dir.iterdir() if d.is_dir()], reverse=True)
            for r in self.runs:
                self.model_combo.addItem(r.name, str(r))
        
        if not self.runs:
            self.model_combo.addItem("Nenhum treino encontrado", "")
            self.model_combo.setEnabled(False)
            
        model_layout.addWidget(self.model_combo)
        layout.addWidget(model_box)

        # Overlays
        overlay_box = QGroupBox("Overlays iniciais")
        ov_layout = QHBoxLayout(overlay_box)
        self.chk_face = QCheckBox("Face Mesh")
        self.chk_face.setChecked(True)
        self.chk_pose = QCheckBox("Esqueleto")
        self.chk_pose.setChecked(True)
        ov_layout.addWidget(self.chk_face)
        ov_layout.addWidget(self.chk_pose)
        ov_layout.addStretch()
        layout.addWidget(overlay_box)

        # Botões
        btns = QDialogButtonBox()
        btn_start = QPushButton("▶  Iniciar")
        btn_start.setObjectName("accent")
        btn_start.clicked.connect(self.accept)
        btn_cancel = QPushButton("Cancelar")
        btn_cancel.clicked.connect(self.reject)
        btns.addButton(btn_start, QDialogButtonBox.AcceptRole)
        btns.addButton(btn_cancel, QDialogButtonBox.RejectRole)
        layout.addWidget(btns)

    @property
    def camera_index(self) -> int:
        return self.camera_spin.value()

    @property
    def run_dir(self) -> Path:
        data = self.model_combo.currentData()
        return Path(data) if data else None

    @property
    def show_face(self) -> bool:
        return self.chk_face.isChecked()

    @property
    def show_pose(self) -> bool:
        return self.chk_pose.isChecked()


# ─── Janela Principal ─────────────────────────────────────────────────────────

class MainWindow(QMainWindow):
    def __init__(self, camera_idx: int, run_dir: Path,
                 show_face: bool, show_pose: bool):
        super().__init__()
        self.setWindowTitle("MindFlow AI — Inferência em Tempo Real")
        self.resize(1280, 720)

        training_dir = ROOT / "outputs" / "training"

        # Widget central
        central = QWidget()
        self.setCentralWidget(central)
        root_layout = QHBoxLayout(central)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # ── Feed da câmera ──
        self.video_label = QLabel()
        self.video_label.setMinimumSize(800, 540)
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setStyleSheet(
            "background: rgba(0,0,0,80);"
            "border: 2px solid rgba(255,255,255,100);"
            "border-radius: 12px;"
        )
        root_layout.addWidget(self.video_label, 1)

        # ── Painel lateral ──
        sidebar = QWidget()
        sidebar.setFixedWidth(340)
        sidebar.setStyleSheet(
            "background: rgba(255,255,255,140);"
            "border-left: 1.5px solid rgba(255,255,255,200);"
        )
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(16, 16, 16, 16)
        sidebar_layout.setSpacing(12)
        root_layout.addWidget(sidebar)

        # Header
        hdr = QLabel("🧠  MindFlow AI")
        hdr.setFont(QFont("Inter", 16, QFont.Bold))
        hdr.setStyleSheet(f"color: {ACCENT}; letter-spacing: 1px;")
        sidebar_layout.addWidget(hdr)

        self.lbl_status = QLabel("Iniciando...")
        self.lbl_status.setStyleSheet(f"color: {MUTED_CLR}; font-size: 11px;")
        sidebar_layout.addWidget(self.lbl_status)

        sep = QFrame(); sep.setFrameShape(QFrame.HLine)
        sidebar_layout.addWidget(sep)

        # ── Gauges das 4 dimensões ──
        gauges_box = QGroupBox("Estados Cognitivos")
        gauges_grid = QGridLayout(gauges_box)
        gauges_grid.setSpacing(8)

        self.gauges: List[GaugeWidget] = []
        self.level_labels: List[QLabel] = []
        for i, (name, color) in enumerate(zip(TASK_DISPLAY, TASK_COLORS)):
            gauge = GaugeWidget(name, color)
            self.gauges.append(gauge)
            row, col = divmod(i, 2)
            cell = QVBoxLayout()
            cell.addWidget(gauge, alignment=Qt.AlignCenter)
            gauges_grid.addLayout(cell, row, col)

        sidebar_layout.addWidget(gauges_box)

        # ── Barras de progresso ──
        bars_box = QGroupBox("Nível de Confiança")
        bars_layout = QVBoxLayout(bars_box)
        bars_layout.setSpacing(6)
        self.progress_bars: List[QProgressBar] = []
        for name, color in zip(TASK_DISPLAY, TASK_COLORS):
            row = QHBoxLayout()
            lbl = QLabel(f"{name[:4]}.")
            lbl.setFixedWidth(36)
            lbl.setStyleSheet(f"color: {color}; font-size: 10px; font-weight: bold;")
            row.addWidget(lbl)
            pb = QProgressBar()
            pb.setRange(0, 100)
            pb.setValue(0)
            # Barra cor sólida — igual à cor do gauge correspondente
            pb.setStyleSheet(
                f"QProgressBar {{ background: rgba(231,224,213,160); border: none;"
                f" border-radius: 6px; color: #57534E; font-size: 10px; font-weight: bold; }}"
                f" QProgressBar::chunk {{ background: {color}; border-radius: 6px; }}"
            )
            row.addWidget(pb)
            bars_layout.addLayout(row)
            self.progress_bars.append(pb)
        sidebar_layout.addWidget(bars_box)

        # ── Controles ──
        ctrl_box = QGroupBox("Controles")
        ctrl_layout = QVBoxLayout(ctrl_box)
        ctrl_layout.setSpacing(8)

        self.chk_face = QCheckBox("Face Mesh  [L]")
        self.chk_face.setChecked(show_face)
        self.chk_face.stateChanged.connect(self._toggle_face)
        ctrl_layout.addWidget(self.chk_face)

        self.chk_pose = QCheckBox("Esqueleto corporal  [P]")
        self.chk_pose.setChecked(show_pose)
        self.chk_pose.stateChanged.connect(self._toggle_pose)
        ctrl_layout.addWidget(self.chk_pose)

        btn_row = QHBoxLayout()
        btn_screenshot = QPushButton("📸  Screenshot  [S]")
        btn_screenshot.clicked.connect(self._screenshot)
        btn_row.addWidget(btn_screenshot)

        btn_reset = QPushButton("↺  Reset  [R]")
        btn_reset.clicked.connect(self._reset)
        btn_row.addWidget(btn_reset)
        ctrl_layout.addLayout(btn_row)

        btn_quit = QPushButton("✕  Encerrar  [Q]")
        btn_quit.setObjectName("danger")
        btn_quit.clicked.connect(self.close)
        ctrl_layout.addWidget(btn_quit)

        sidebar_layout.addWidget(ctrl_box)
        sidebar_layout.addStretch()

        # ── Worker ──
        self.worker = InferenceWorker(
            camera_idx=camera_idx,
            run_dir=run_dir,
        )
        self.worker.show_face = show_face
        self.worker.show_pose = show_pose
        self.worker.frame_ready.connect(self._on_frame)
        self.worker.error.connect(self._on_error)
        self.worker.start()

        self._frame_count = 0
        self._screenshot_dir = ROOT / "outputs" / "inference_screenshots"
        self._screenshot_dir.mkdir(parents=True, exist_ok=True)

    def _on_frame(self, frame: np.ndarray, probs_list: list, buf_len: int, fps: float):
        # Atualiza vídeo
        h, w, ch = frame.shape
        qt_img = QImage(frame.data, w, h, ch * w, QImage.Format_RGB888)
        pix = QPixmap.fromImage(qt_img).scaled(
            self.video_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        self.video_label.setPixmap(pix)

        seq_len = self.worker.seq_len
        self.lbl_status.setText(
            f"FPS: {fps:.1f}   Buffer: {min(buf_len, seq_len)}/{seq_len}   "
            f"{'🟢 Ativo' if buf_len >= seq_len else '🟡 Aguardando...'}"
        )

        if probs_list:
            for i, (gauge, pb, probs) in enumerate(
                zip(self.gauges, self.progress_bars, probs_list)
            ):
                # Score contínuo: valor esperado das probabilidades softmax
                class_scores = np.array([0.0, 1/3, 2/3, 1.0])
                score = float(np.dot(probs, class_scores))   # 0.0 – 1.0

                # Rótulo derivado do score contínuo
                if score < 0.25:
                    label = "Muito Baixo"
                elif score < 0.50:
                    label = "Baixo"
                elif score < 0.75:
                    label = "Alto"
                else:
                    label = "Muito Alto"

                # Confiança = probabilidade da classe mais provável (certeza do modelo)
                confidence = float(probs.max())

                gauge.set_value(score, label)
                pb.setValue(int(confidence * 100))


        self._frame_count += 1

    def _on_error(self, msg: str):
        self.lbl_status.setText(f"❌ Erro: {msg}")
        self.lbl_status.setStyleSheet("color: #F44336; font-size: 11px;")

    def _toggle_face(self, state):
        self.worker.show_face = bool(state)

    def _toggle_pose(self, state):
        self.worker.show_pose = bool(state)

    def _screenshot(self):
        path = self._screenshot_dir / f"mindflow_{self._frame_count:06d}.png"
        pix  = self.video_label.pixmap()
        if pix:
            pix.save(str(path))
            self.lbl_status.setText(f"📸 Salvo: {path.name}")

    def _reset(self):
        self.worker.infer_every = 15
        self.lbl_status.setText("↺ Buffer resetado")

    def keyPressEvent(self, event):
        k = event.key()
        if k in (Qt.Key_Q, Qt.Key_Escape):
            self.close()
        elif k == Qt.Key_S:
            self._screenshot()
        elif k == Qt.Key_R:
            self._reset()
        elif k == Qt.Key_L:
            self.chk_face.setChecked(not self.chk_face.isChecked())
        elif k == Qt.Key_P:
            self.chk_pose.setChecked(not self.chk_pose.isChecked())

    def closeEvent(self, event):
        self.worker.stop()
        self.worker.wait(3000)
        super().closeEvent(event)


# ─── Entry point ─────────────────────────────────────────────────────────────

def run_gui():
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLESHEET)
    app.setApplicationName("MindFlow AI")

    dialog = LaunchDialog()
    if dialog.exec_() != QDialog.Accepted:
        sys.exit(0)

    win = MainWindow(
        camera_idx=dialog.camera_index,
        run_dir=dialog.run_dir,
        show_face=dialog.show_face,
        show_pose=dialog.show_pose,
    )
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    run_gui()
