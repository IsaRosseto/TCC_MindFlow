"""
training/preprocessing.py
==========================
Pré-processamento do pipeline de treinamento do MindFlow AI.

Etapas (na ordem correta conforme metodologia):
  1. Divisão subject-aware 60/20/20  ← antes de qualquer transformação
  2. Normalização Z-score             ← fit apenas no treino
  3. SMOTE                            ← apenas no treino, pós-normalização
  4. PCA (opcional)                   ← fit apenas no treino

Ordem é crítica:
  - Split ANTES da normalização: evita data leakage do scaler
  - Normalização ANTES do SMOTE: distâncias uniformes na síntese de amostras
  - SMOTE APENAS no treino: val e test permanecem com distribuição real
  - PCA APÓS SMOTE: componentes calculados sobre espaço já balanceado

Referências metodológicas:
  - MindFlow_Metodologia.pdf §4.1 decisões 4, 5, 6, 7
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, Tuple

import joblib
import numpy as np
from imblearn.over_sampling import SMOTE
from sklearn.decomposition import PCA
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler

from training.config import MindFlowTrainingConfig, DEFAULT_CFG

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tipos
# ---------------------------------------------------------------------------

SplitData = Tuple[
    np.ndarray, np.ndarray,   # X_train, y_train
    np.ndarray, np.ndarray,   # X_val,   y_val
    np.ndarray, np.ndarray,   # X_test,  y_test
]


# ---------------------------------------------------------------------------
# 1. Divisão subject-aware
# ---------------------------------------------------------------------------

def split_by_subject(
    X: np.ndarray,
    y: np.ndarray,
    subjects: np.ndarray,
    train_ratio: float = 0.60,
    val_ratio:   float = 0.20,
    seed:        int   = 42,
) -> Tuple[
    np.ndarray, np.ndarray, np.ndarray,   # índices treino, val, teste
]:
    """
    Divide o dataset por participante (subject-aware split).

    Garante que nenhum participante apareça em mais de uma partição.
    Isso é essencial para avaliar generalização real do modelo — se um
    participante estiver no treino e no teste, o modelo pode ter aprendido
    padrões idiossincráticos daquele rosto específico.

    Parâmetros
    ----------
    X, y, subjects : saída de dataset.build_sequences()
    train_ratio    : fração do dataset para treino
    val_ratio      : fração para validação
    seed           : reprodutibilidade

    Retorna
    -------
    idx_train, idx_val, idx_test — arrays de índices
    """
    test_ratio = round(1.0 - train_ratio - val_ratio, 10)

    # Primeira divisão: separa teste
    splitter_test = GroupShuffleSplit(
        n_splits=1, test_size=test_ratio, random_state=seed
    )
    idx_trainval, idx_test = next(
        splitter_test.split(X, y, groups=subjects)
    )

    # Segunda divisão: divide treino/val dentro do trainval
    val_fraction_of_trainval = val_ratio / (train_ratio + val_ratio)
    splitter_val = GroupShuffleSplit(
        n_splits=1, test_size=val_fraction_of_trainval, random_state=seed
    )
    idx_train, idx_val = next(
        splitter_val.split(X[idx_trainval], y[idx_trainval], groups=subjects[idx_trainval])
    )
    # Remapear para índices globais
    idx_train = idx_trainval[idx_train]
    idx_val   = idx_trainval[idx_val]

    _log_split_stats(y, subjects, idx_train, idx_val, idx_test)
    return idx_train, idx_val, idx_test


def _log_split_stats(
    y: np.ndarray,
    subjects: np.ndarray,
    idx_train: np.ndarray,
    idx_val:   np.ndarray,
    idx_test:  np.ndarray,
) -> None:
    total = len(y)
    for name, idx in [("Treino", idx_train), ("Val", idx_val), ("Teste", idx_test)]:
        dist = dict(zip(*np.unique(y[idx], return_counts=True)))
        subjs = np.unique(subjects[idx])
        logger.info(
            "  %s: %d amostras (%.0f%%) | %d subjects | classes: %s",
            name,
            len(idx),
            100 * len(idx) / total,
            len(subjs),
            dist,
        )

    # Verifica ausência de leakage
    s_train = set(subjects[idx_train])
    s_val   = set(subjects[idx_val])
    s_test  = set(subjects[idx_test])
    overlap_tv = s_train & s_val
    overlap_tt = s_train & s_test
    overlap_vt = s_val   & s_test
    if overlap_tv or overlap_tt or overlap_vt:
        logger.warning(
            "⚠️  Data leakage detectado! Subjects em múltiplas partições: "
            "train∩val=%s  train∩test=%s  val∩test=%s",
            overlap_tv, overlap_tt, overlap_vt,
        )
    else:
        logger.info("  ✅ Zero leakage — subjects isolados por partição")


# ---------------------------------------------------------------------------
# 2. Normalização Z-score
# ---------------------------------------------------------------------------

def fit_scaler(
    X_train: np.ndarray,
    scaler_type: str = "standard",
    save_path: Optional[Path] = None,
) -> object:
    """
    Ajusta o scaler APENAS nos dados de treino.

    Parâmetros
    ----------
    X_train : (N_train, seq_len, 120)
    scaler_type : "standard" | "minmax" | "robust"
    save_path : caminho para serializar o scaler (necessário em produção)

    Retorna
    -------
    scaler ajustado (sklearn-compatible)
    """
    scaler_map = {
        "standard": StandardScaler,
        "minmax":   MinMaxScaler,
        "robust":   RobustScaler,
    }
    if scaler_type not in scaler_map:
        raise ValueError(f"scaler_type inválido: {scaler_type}. Opções: {list(scaler_map)}")

    scaler = scaler_map[scaler_type]()

    # Reshape para 2D: (N*seq_len, 120) → fit → reshape de volta
    n, seq, feat = X_train.shape
    X_flat = X_train.reshape(-1, feat)
    scaler.fit(X_flat)
    logger.info("Scaler '%s' ajustado em %d amostras × %d features", scaler_type, *X_flat.shape)

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(scaler, save_path)
        logger.info("Scaler salvo em: %s", save_path)

    return scaler


def apply_scaler(X: np.ndarray, scaler) -> np.ndarray:
    """Aplica o scaler a qualquer partição (train/val/test)."""
    n, seq, feat = X.shape
    X_flat = X.reshape(-1, feat)
    X_scaled = scaler.transform(X_flat)
    return X_scaled.reshape(n, seq, feat)


# ---------------------------------------------------------------------------
# 3. SMOTE
# ---------------------------------------------------------------------------

def apply_smote(
    X_train: np.ndarray,
    y_train: np.ndarray,
    k_neighbors: int = 5,
    seed: int = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Balanceia o conjunto de treino com SMOTE.

    O SMOTE opera em 2D, então achata a dimensão de sequência antes
    e restaura depois. Isso é equivalente a tratar cada sequência de
    30 frames como um único vetor de 30×120=3600 dimensões para fins
    de geração de amostras sintéticas.

    Limitação (registrar no TCC): SMOTE não preserva a estrutura
    temporal interna da sequência — as amostras sintéticas são
    interpolações lineares entre vizinhos no espaço achatado, o que
    pode gerar sequências temporalmente incoerentes. Alternativa
    futura: TimeGAN ou augmentation temporal.

    Parâmetros
    ----------
    X_train : (N, seq_len, 120) — já normalizado
    y_train : (N,)
    k_neighbors : vizinhos do SMOTE (reduzir se classe minoritária < k+1)
    seed : reprodutibilidade
    """
    n, seq, feat = X_train.shape
    X_flat = X_train.reshape(n, seq * feat)

    # Ajusta k_neighbors se necessário
    min_class_count = np.min(np.bincount(y_train))
    k = min(k_neighbors, min_class_count - 1)
    if k < k_neighbors:
        logger.warning(
            "⚠️  k_neighbors reduzido de %d para %d (classe minoritária tem %d amostras)",
            k_neighbors, k, min_class_count,
        )

    smote = SMOTE(k_neighbors=k, random_state=seed)
    X_resampled, y_resampled = smote.fit_resample(X_flat, y_train)

    n_new = len(X_resampled)
    X_resampled = X_resampled.reshape(n_new, seq, feat)

    logger.info(
        "SMOTE: %d → %d amostras | nova dist: %s",
        n,
        n_new,
        dict(zip(*np.unique(y_resampled, return_counts=True))),
    )
    return X_resampled, y_resampled


# ---------------------------------------------------------------------------
# 4. PCA (opcional)
# ---------------------------------------------------------------------------

def fit_pca(
    X_train: np.ndarray,
    variance_threshold: float = 0.95,
    save_path: Optional[Path] = None,
) -> PCA:
    """
    Ajusta PCA no treino. Reduz a dimensão de features retendo
    `variance_threshold` da variância explicada.

    PCA é aplicado por frame (2D), não por sequência.
    """
    n, seq, feat = X_train.shape
    X_flat = X_train.reshape(-1, feat)

    pca = PCA(n_components=variance_threshold, svd_solver="full", random_state=42)
    pca.fit(X_flat)

    logger.info(
        "PCA ajustado: %d → %d componentes (%.1f%% variância retida)",
        feat,
        pca.n_components_,
        100 * variance_threshold,
    )

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(pca, save_path)
        logger.info("PCA salvo em: %s", save_path)

    return pca


def apply_pca(X: np.ndarray, pca: PCA) -> np.ndarray:
    """Aplica PCA a qualquer partição."""
    n, seq, feat = X.shape
    X_flat = X.reshape(-1, feat)
    X_reduced = pca.transform(X_flat)
    n_components = X_reduced.shape[1]
    return X_reduced.reshape(n, seq, n_components)


# ---------------------------------------------------------------------------
# Função orquestradora
# ---------------------------------------------------------------------------

def preprocess_pipeline(
    X: np.ndarray,
    y: np.ndarray,
    subjects: np.ndarray,
    cfg: MindFlowTrainingConfig = DEFAULT_CFG,
    save_artifacts: bool = True,
) -> Tuple[SplitData, dict]:
    """
    Executa o pipeline completo de pré-processamento na ordem correta.

    Parâmetros
    ----------
    X, y, subjects : saída de dataset.load_dataset()
    cfg : configuração completa
    save_artifacts : persiste scaler e PCA em disco

    Retorna
    -------
    (X_train, y_train, X_val, y_val, X_test, y_test), artifacts_dict
    """
    from training.config import SCALER_PATH, PCA_PATH
    p = cfg.preprocess

    logger.info("=" * 55)
    logger.info("PIPELINE DE PRÉ-PROCESSAMENTO")
    logger.info("=" * 55)

    # 1. Split
    logger.info("[1/4] Divisão subject-aware %s/%s/%s",
                int(p.train_ratio*100), int(p.val_ratio*100), int(p.test_ratio*100))
    idx_train, idx_val, idx_test = split_by_subject(
        X, y, subjects,
        train_ratio=p.train_ratio,
        val_ratio=p.val_ratio,
        seed=p.split_random_state,
    )
    X_train, y_train = X[idx_train], y[idx_train]
    X_val,   y_val   = X[idx_val],   y[idx_val]
    X_test,  y_test  = X[idx_test],  y[idx_test]

    # 2. Normalização (fit SOMENTE no treino)
    logger.info("[2/4] Normalização Z-score (fit no treino)")
    scaler = fit_scaler(
        X_train,
        scaler_type=p.scaler,
        save_path=SCALER_PATH if save_artifacts else None,
    )
    X_train = apply_scaler(X_train, scaler)
    X_val   = apply_scaler(X_val,   scaler)
    X_test  = apply_scaler(X_test,  scaler)

    # 3. SMOTE (somente no treino)
    logger.info("[3/4] SMOTE (somente no treino)")
    X_train, y_train = apply_smote(
        X_train, y_train,
        k_neighbors=p.smote_k_neighbors,
        seed=p.smote_random_state,
    )

    # 4. PCA (opcional)
    pca = None
    if p.use_pca:
        logger.info("[4/4] PCA (fit no treino pós-SMOTE)")
        pca = fit_pca(
            X_train,
            variance_threshold=p.pca_variance_threshold,
            save_path=PCA_PATH if save_artifacts else None,
        )
        X_train = apply_pca(X_train, pca)
        X_val   = apply_pca(X_val,   pca)
        X_test  = apply_pca(X_test,  pca)
    else:
        logger.info("[4/4] PCA desativado (use_pca=False)")

    logger.info("=" * 55)
    logger.info("Pré-processamento concluído.")
    logger.info(
        "  X_train: %s  X_val: %s  X_test: %s",
        X_train.shape, X_val.shape, X_test.shape,
    )
    logger.info("=" * 55)

    artifacts = {"scaler": scaler, "pca": pca}
    return (X_train, y_train, X_val, y_val, X_test, y_test), artifacts


# ---------------------------------------------------------------------------
# Smoke test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")

    from training.dataset import load_dataset

    print("=== Smoke test: preprocessing pipeline ===\n")
    X, y, subjects = load_dataset(use_synthetic=True)

    (X_train, y_train, X_val, y_val, X_test, y_test), artifacts = preprocess_pipeline(
        X, y, subjects, save_artifacts=False
    )

    print(f"\n  X_train : {X_train.shape}  y_train: {y_train.shape}")
    print(f"  X_val   : {X_val.shape}  y_val  : {y_val.shape}")
    print(f"  X_test  : {X_test.shape}  y_test : {y_test.shape}")
    print(f"  Scaler  : {artifacts['scaler']}")
    print(f"  PCA     : {artifacts['pca']}")
    print("\n✅  Preprocessing OK")
