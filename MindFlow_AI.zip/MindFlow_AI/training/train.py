"""
training/train.py
=================
Loop de treinamento multi-output do MindFlow AI.

Loss total = soma das 4 CrossEntropyLoss (uma por dimensão DAiSEE).
Early stopping e checkpoint monitoram o val_loss total.
"""

from __future__ import annotations

import json
import logging
import random
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.optim import Adam
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader
from sklearn.metrics import f1_score

from training.config import MindFlowTrainingConfig, DEFAULT_CFG
from training.dataset import MindFlowDataset, load_dataset, TASK_NAMES
from training.model import MindFlowLSTM, build_model
from training.preprocessing import preprocess_pipeline

logger = logging.getLogger(__name__)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def resolve_device(device_str: str) -> torch.device:
    if device_str == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(device_str)
    logger.info("Device: %s", device)
    return device


def _run_epoch(
    model:      MindFlowLSTM,
    loader:     DataLoader,
    criterions: List[nn.CrossEntropyLoss],
    optimizer:  Optional[torch.optim.Optimizer],
    device:     torch.device,
    phase:      str,
) -> Tuple[float, float, float]:
    """
    Executa uma época multi-output.
    Retorna (loss_total_mean, accuracy_engagement, f1_macro_engagement).
    """
    is_train = (phase == "train")
    model.train() if is_train else model.eval()

    total_loss   = 0.0
    all_preds:   List[int] = []
    all_labels:  List[int] = []

    context = torch.enable_grad if is_train else torch.no_grad

    with context():
        for X_batch, y_batch in loader:
            X_batch = X_batch.to(device)         # (B, seq, dim)
            y_batch = y_batch.to(device)         # (B, 4)

            logits_list = model(X_batch)          # lista de 4 tensors (B, 4)

            # Soma das 4 losses
            loss = sum(
                criterions[t](logits_list[t], y_batch[:, t])
                for t in range(len(TASK_NAMES))
            )

            if is_train:
                optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()

            total_loss += loss.item() * len(y_batch)

            # Métricas de progresso: foca em engagement (task 0)
            preds = logits_list[0].argmax(dim=-1)
            all_preds.extend(preds.cpu().numpy().tolist())
            all_labels.extend(y_batch[:, 0].cpu().numpy().tolist())

    n         = len(all_labels)
    loss_mean = total_loss / n
    accuracy  = sum(p == l for p, l in zip(all_preds, all_labels)) / n
    f1_macro  = f1_score(all_labels, all_preds, average="macro", zero_division=0)

    return loss_mean, accuracy, f1_macro


def train_model(
    cfg:        MindFlowTrainingConfig = DEFAULT_CFG,
    save_model: bool = True,
) -> Dict:
    set_seed(cfg.train.seed)
    device = resolve_device(cfg.train.device)

    # 1. Dados
    logger.info("Carregando splits do DAiSEE...")
    data = load_dataset(cfg=cfg, splits=("train", "validation", "test"))
    X_train, y_train, _ = data["train"]
    X_val,   y_val,   _ = data["validation"]
    X_test,  y_test,  _ = data["test"]

    # 2. Pré-processamento (usa engagement=y[:,0] como alvo do SMOTE)
    logger.info("Pré-processando...")
    (X_train, y_train, X_val, y_val, X_test, y_test), artifacts = preprocess_pipeline(
        X_train, y_train, X_val, y_val, X_test, y_test,
        cfg=cfg,
        save_artifacts=save_model,
    )

    # 3. DataLoaders
    ds_train = MindFlowDataset(X_train, y_train)
    ds_val   = MindFlowDataset(X_val,   y_val)

    loader_train = DataLoader(ds_train, batch_size=cfg.train.batch_size,
                              shuffle=True, num_workers=4,
                              pin_memory=(device.type == "cuda"))
    loader_val   = DataLoader(ds_val,   batch_size=cfg.train.batch_size,
                              shuffle=False, num_workers=4)

    # 4. Modelo
    input_dim = X_train.shape[2]
    model = build_model(cfg, input_dim=input_dim).to(device)

    # 5. Uma CrossEntropyLoss por dimensão (com pesos da sua distribuição)
    criterions = []
    for t in range(len(TASK_NAMES)):
        w = ds_train.compute_class_weights(task_idx=t).to(device)
        criterions.append(nn.CrossEntropyLoss(weight=w))
        logger.info("Pesos [%s]: %s", TASK_NAMES[t], w.cpu().tolist())

    # 6. Optimizer e scheduler
    optimizer = Adam(model.parameters(),
                     lr=cfg.train.learning_rate,
                     weight_decay=cfg.train.weight_decay)
    scheduler = ReduceLROnPlateau(optimizer, mode="min",
                                  patience=cfg.train.lr_patience,
                                  factor=cfg.train.lr_factor)

    # 7. Loop
    history: Dict = {
        "train_loss": [], "train_acc": [], "train_f1": [],
        "val_loss":   [], "val_acc":   [], "val_f1":   [],
        "lr": [],
    }

    best_val_loss     = float("inf")
    epochs_no_improve = 0
    best_epoch        = 0
    # Usa o diretório do config

    logger.info("=" * 60)
    logger.info("INICIANDO TREINAMENTO — %d épocas máx. | device=%s", cfg.train.max_epochs, device)
    logger.info("Input dim (pós-PCA): %d | Tarefas: %d × %d classes", input_dim, len(TASK_NAMES), 4)
    logger.info("=" * 60)

    for epoch in range(1, cfg.train.max_epochs + 1):
        t_loss, t_acc, t_f1 = _run_epoch(model, loader_train, criterions, optimizer, device, "train")
        v_loss, v_acc, v_f1 = _run_epoch(model, loader_val,   criterions, None,      device, "val")

        current_lr = optimizer.param_groups[0]["lr"]
        scheduler.step(v_loss)

        history["train_loss"].append(t_loss)
        history["train_acc"].append(t_acc)
        history["train_f1"].append(t_f1)
        history["val_loss"].append(v_loss)
        history["val_acc"].append(v_acc)
        history["val_f1"].append(v_f1)
        history["lr"].append(current_lr)

        logger.info(
            "Época %3d/%d | train loss=%.4f acc=%.3f f1=%.3f | "
            "val loss=%.4f acc=%.3f f1=%.3f | lr=%.2e",
            epoch, cfg.train.max_epochs,
            t_loss, t_acc, t_f1, v_loss, v_acc, v_f1, current_lr,
        )

        if v_loss < best_val_loss:
            best_val_loss = v_loss
            best_epoch    = epoch
            epochs_no_improve = 0
            if save_model:
                torch.save(model.state_dict(), cfg.model_path)
                logger.info("  💾 Checkpoint salvo (val_loss=%.4f)", best_val_loss)
        else:
            epochs_no_improve += 1

        if epochs_no_improve >= cfg.train.early_stop_patience:
            logger.info("⏹  Early stopping na época %d (melhor: época %d)", epoch, best_epoch)
            break

    logger.info("=" * 60)
    logger.info("Treinamento concluído. Melhor época: %d", best_epoch)

    if save_model and cfg.eval.save_history:
        history_path = cfg.history_path
        with open(history_path, "w") as f:
            json.dump(history, f, indent=2)
        logger.info("Histórico salvo em: %s", history_path)

    history["_test_data"]  = (X_test, y_test)
    history["_model"]      = model
    history["_artifacts"]  = artifacts
    history["_best_epoch"] = best_epoch
    history["_input_dim"]  = input_dim

    return history
