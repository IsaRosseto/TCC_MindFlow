"""
training/evaluate.py
====================
Avaliação multi-output do modelo MindFlow AI no conjunto de teste.

Reporta métricas para cada uma das 4 dimensões DAiSEE:
  engagement, boredom, confusion, frustration
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)

from training.config import MindFlowTrainingConfig, DEFAULT_CFG
from training.dataset import MindFlowDataset, TASK_NAMES, TASK_DISPLAY_NAMES, LEVEL_NAMES
from training.model import MindFlowLSTM, build_model, load_model

logger = logging.getLogger(__name__)

# Nomes de nível para exibição (0-3)
_LEVEL_LABELS = ["very_low", "low", "high", "very_high"]


def run_inference(
    model:      MindFlowLSTM,
    X:          np.ndarray,
    device:     torch.device,
    batch_size: int = 128,
) -> Tuple[np.ndarray, List[np.ndarray]]:
    """
    Roda inferência multi-output em batch.

    Retorna
    -------
    preds : (N, 4)  — classe predita por dimensão
    probs : lista de 4 arrays (N, 4) — probabilidades por dimensão
    """
    model = model.to(device)
    model.eval()

    all_preds: List[List[int]] = []
    all_probs: List[List[np.ndarray]] = [[] for _ in TASK_NAMES]

    with torch.no_grad():
        for start in range(0, len(X), batch_size):
            x_bat = torch.from_numpy(X[start: start + batch_size]).float().to(device)
            logits_list = model(x_bat)   # lista de 4 tensors (B, 4)

            batch_preds = []
            for t, logits in enumerate(logits_list):
                probs = torch.softmax(logits, dim=-1)
                preds = probs.argmax(dim=-1)
                batch_preds.append(preds.cpu().numpy())
                all_probs[t].extend(probs.cpu().numpy().tolist())

            # combina em (B, 4)
            batch_preds_np = np.stack(batch_preds, axis=1)
            all_preds.extend(batch_preds_np.tolist())

    preds = np.array(all_preds, dtype=np.int64)         # (N, 4)
    probs = [np.array(p) for p in all_probs]             # 4 × (N, 4)
    return preds, probs


def compute_metrics_per_task(
    y_true: np.ndarray,   # (N, 4)
    y_pred: np.ndarray,   # (N, 4)
) -> Dict:
    """Calcula métricas para cada dimensão separadamente."""
    results = {}

    for t, (task, display) in enumerate(zip(TASK_NAMES, TASK_DISPLAY_NAMES)):
        yt = y_true[:, t]
        yp = y_pred[:, t]

        acc      = accuracy_score(yt, yp)
        f1_mac   = f1_score(yt, yp, average="macro",    zero_division=0)
        f1_wei   = f1_score(yt, yp, average="weighted", zero_division=0)
        prec_mac = precision_score(yt, yp, average="macro", zero_division=0)
        rec_mac  = recall_score(yt, yp,    average="macro", zero_division=0)
        cm       = confusion_matrix(yt, yp, labels=[0, 1, 2, 3]).tolist()

        per_level = {}
        for i, lbl in enumerate(_LEVEL_LABELS):
            per_level[lbl] = {
                "support":   int((yt == i).sum()),
                "precision": float(precision_score(yt, yp, labels=[i], average="macro", zero_division=0)),
                "recall":    float(recall_score(yt, yp,    labels=[i], average="macro", zero_division=0)),
                "f1":        float(f1_score(yt, yp,        labels=[i], average="macro", zero_division=0)),
            }

        report_str = classification_report(
            yt, yp,
            labels=list(range(4)),
            target_names=_LEVEL_LABELS,
            zero_division=0,
        )

        results[task] = {
            "display_name":          display,
            "accuracy":              round(float(acc),      4),
            "f1_macro":              round(float(f1_mac),   4),
            "f1_weighted":           round(float(f1_wei),   4),
            "precision_macro":       round(float(prec_mac), 4),
            "recall_macro":          round(float(rec_mac),  4),
            "confusion_matrix":      cm,
            "per_level":             per_level,
            "classification_report": report_str,
        }

    return results


def print_metrics(task_metrics: Dict) -> None:
    sep = "=" * 60
    print(f"\n{sep}")
    print("  RESULTADOS NO CONJUNTO DE TESTE — MindFlow AI (multi-output)")
    print(sep)

    for task, m in task_metrics.items():
        print(f"\n  [{m['display_name']}]")
        print(f"    Accuracy       : {m['accuracy']:.4f}  ({m['accuracy']*100:.1f}%)")
        print(f"    F1-macro       : {m['f1_macro']:.4f}")
        print(f"    F1-weighted    : {m['f1_weighted']:.4f}")
        print(f"    Precision-macro: {m['precision_macro']:.4f}")
        print(f"    Recall-macro   : {m['recall_macro']:.4f}")
        print(f"    Por nível:")
        for lvl, stats in m["per_level"].items():
            print(f"      {lvl:10s}: prec={stats['precision']:.3f}  "
                  f"rec={stats['recall']:.3f}  f1={stats['f1']:.3f}  n={stats['support']}")

    print(f"\n{sep}\n")


def evaluate_model(
    model:     Optional[MindFlowLSTM] = None,
    X_test:    Optional[np.ndarray]   = None,
    y_test:    Optional[np.ndarray]   = None,
    cfg:       MindFlowTrainingConfig  = DEFAULT_CFG,
    input_dim: Optional[int]           = None,
    save:      bool = True,
) -> Dict:
    device = torch.device("cpu")
    if model is not None:
        model = model.to(device)

    if model is None:
        if not MODEL_PATH.exists():
            raise FileNotFoundError(f"Modelo não encontrado em {MODEL_PATH}.")
        model = load_model(MODEL_PATH, cfg=cfg, input_dim=input_dim, device="cpu")

    if X_test is None or y_test is None:
        raise ValueError("X_test e y_test devem ser fornecidos.")

    logger.info("Rodando inferência em %d amostras de teste...", len(X_test))
    y_pred, _ = run_inference(model, X_test, device, batch_size=cfg.train.batch_size)

    # y_test pode ser (N,) do dataset antigo ou (N, 4) do novo
    if y_test.ndim == 1:
        # compatibilidade: expande para (N, 4) com engagement na col 0 e 0 nas demais
        y_test_4d = np.zeros((len(y_test), 4), dtype=np.int64)
        y_test_4d[:, 0] = y_test
        y_test = y_test_4d

    task_metrics = compute_metrics_per_task(y_true=y_test, y_pred=y_pred)
    print_metrics(task_metrics)

    if save:
        metrics_path = cfg.metrics_path
        metrics_path.parent.mkdir(parents=True, exist_ok=True)
        metrics_to_save = {
            task: {k: v for k, v in m.items() if k != "classification_report"}
            for task, m in task_metrics.items()
        }
        with open(metrics_path, "w") as f:
            json.dump(metrics_to_save, f, indent=2)
        logger.info("Métricas salvas em: %s", metrics_path)

        report_path = cfg.report_path
        with open(report_path, "w") as f:
            for task, m in task_metrics.items():
                f.write(f"\n=== {m['display_name']} ===\n")
                f.write(m["classification_report"])
        logger.info("Relatório salvo em: %s", report_path)

    return task_metrics
