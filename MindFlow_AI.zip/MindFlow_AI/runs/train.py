"""
runs/train.py
=============
Script de treino do MindFlow AI.

Uso:
    python runs/train.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%H:%M:%S",
)

from training.config import DEFAULT_CFG
from training.train import train_model
from training.evaluate import evaluate_model

if __name__ == "__main__":
    print("=" * 60)
    print("  MindFlow AI — Treinamento")
    print("=" * 60)

    history = train_model(cfg=DEFAULT_CFG, save_model=True)

    model          = history["_model"]
    X_test, y_test = history["_test_data"]
    input_dim      = history["_input_dim"]

    metrics = evaluate_model(
        model=model,
        X_test=X_test,
        y_test=y_test,
        cfg=DEFAULT_CFG,
        input_dim=input_dim,
        save=True,
    )

    print(f"\n✅ Treino concluído. Artefatos salvos em: {DEFAULT_CFG.output_dir}")
    print("   Rode agora: python runs/plot.py   para gerar os gráficos.")
